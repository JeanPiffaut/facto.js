<?php
	/*
		Plugin Name: Facto - facturaci&oacute;n electr&oacute;nica
		Description: Integraci&oacute;n Facto
		Version:     0.1
		Author:      OML
	*/


//cambia los .js

/*
 * UTILIZAREMOS EL address-i18n.js de woocommerce
add_action('wp_enqueue_scripts', 'override_woo_frontend_scripts');	
function override_woo_frontend_scripts() {
	wp_deregister_script('wc-address-i18n');
	wp_enqueue_script('wc-checkout', '/wp-content/plugins/woo/address-i18n.js', array('jquery', 'woocommerce', 'wc-country-select', 'wc-address-i18n'), null, true);
}
*/
	
//modificamos los campos
add_filter( 'woocommerce_checkout_fields', 'OML_checkout_fields' );
function OML_checkout_fields($fields){
	$fields['billing']['billing_state']['placeholder'] = 'Seleccione una Comunas';
	$fields['billing']['billing_state']['label'] = 'Comuna';

	$fields['shipping']['shipping_state']['placeholder'] = 'Seleccione una Comuna';
	$fields['shipping']['shipping_state']['label'] = 'Comuna';

	//unset($fields['billing']['billing_postcode']);
	//unset($fields['shipping']['shipping_postcode']);
	
	unset($fields['billing']['billing_company']);
	unset($fields['shipping']['shipping_company']); 
	
	//unset($fields['billing']['billing_city']);
	//unset($fields['shipping']['shipping_city']);
	
	return $fields;
}
	
	
//agregamos los campos
add_action( 'woocommerce_after_order_notes', 'oml_custom_checkout_field' );
function oml_custom_checkout_field( $checkout ) {
	//echo "ghjgjhgjhgj";
	//var_dump(mail ( "davoflores@hotmail.com" , "subject" , "ghj" ));

	$opciones = array();
	if(get_option('facto_checkbox_fe') == "on") $opciones['fe'] = 'Factura electr&oacute;nica';
	if(get_option('facto_checkbox_fee') == "on") $opciones['fee'] = 'Factura exenta electr&oacute;nica';
	if(get_option('facto_checkbox_be') == "on") $opciones['be'] = 'Boleta electr&oacute;nica';
	if(get_option('facto_checkbox_bee') == "on") $opciones['bee'] = 'Boleta exenta electr&oacute;nica';
	
	$array_kind_of_legal_invoice = array(
										'type'          => 'select',
										'options' 		=> $opciones,
										'class'         => array('form-row-wide'),
										'label'         => __('Tipo de documento'),
										'placeholder'   => __('eleccione el tipo de documento')
									);
	 
	 $array_campo_rut = array(
										'type'          => 'text',
										'class'         => array('form-row-wide'),
										'label'         => __('RUT'),
										'required'		=> true,
										'placeholder'   => __('Ingrese el RUT')
								);
	 
	 $array_campo_razon_social = array(
										'type'          => 'text',
										'class'         => array('form-row-wide'),
										'label'         => __('Raz&oacute;n social'),
										'required'		=> true,
										'placeholder'   => __('Indique la raz&oacute;n social.')
										
								);
								
	$array_campo_giro = array(
						'type'          => 'text',
						'class'         => array('form-row-wide'),
						'label'         => __('Giro'),
						'required'		=> true,
						'placeholder'   => __('Indique el giro.')			
				);
				
	$array_campo_receptor_direccion = array(
						'type'          => 'text',
						'class'         => array('form-row-wide'),
						'label'         => __('Direcci&oacute;n del receptor'),
						'required'		=> true,
						'placeholder'   => __('Indique la direcci&oacute;n del receptor.')			
				);

	/*$arreglo_comunas = array();
	$nombre_comunas = comunas_de_chile(array());
	foreach($nombre_comunas["CL"] as $key => $valor){
		$arreglo_comunas[$valor] = $valor;
	}
	$array_campo_comuna = array(
						'type'          => 'select',
						'class'         => array('form-row-wide'),
						'label'         => __('Comuna'),
						'placeholder'   => __('Indique la comuna.'),
						'options'     => $arreglo_comunas
				);*/

//sanitize_text_field

	$array_campo_comuna = array(
						'type'          => 'text',
						'class'         => array('form-row-wide'),
						'label'         => __('Comuna'),
						'placeholder'   => __('Indique la comuna del receptor.'),		
						'required'		=> true,
				);
				
				
	$array_campo_telefono = array(
						'type'          => 'text',
						'class'         => array('form-row-wide'),
						'label'         => __('Tel&eacute;fono'),
						'required'		=> true,
						'placeholder'   => __('Indique el n&uacute;mero de tel&eacute;fono del receptor.')			
				);
	
	?>	
    <div id="div_datos_de_facto"><br><h3>Ingrese sus datos para recibir su boleta o factura</h3>

	<?php
		woocommerce_form_field( 'campo_receptor_direccion', $array_campo_receptor_direccion, $checkout->get_value( 'campo_receptor_direccion' ));	
		//woocommerce_form_field( 'campo_receptor_comuna', $array_campo_comuna, $checkout->get_value( 'comuna' ));	
		woocommerce_form_field( 'campo_receptor_comuna', $array_campo_comuna, $checkout->get_value( 'campo_receptor_comuna' ));	
		woocommerce_form_field( 'campo_receptor_telefono', $array_campo_telefono, $checkout->get_value( 'campo_receptor_telefono' ));	
		woocommerce_form_field( 'kind_of_legal_invoice', $array_kind_of_legal_invoice, $checkout->get_value( 'kind_of_legal_invoice' ));
	?> 
		<div id='factofacturacionelectronica_div_factura'> <?php
		
			woocommerce_form_field( 'oml_campo_rut', $array_campo_rut, $checkout->get_value( 'oml_campo_rut' ));
			woocommerce_form_field( 'campo_razon_social', $array_campo_razon_social, $checkout->get_value( 'campo_razon_social' ));
			woocommerce_form_field( 'campo_giro', $array_campo_giro, $checkout->get_value( 'campo_giro' ));		
		?> 
		</div>
	</div>
	<?php
	
	//RUT
	//wp_register_script('jquery.script', plugins_url('jquery.script.js', __FILE__));
	//wp_enqueue_script('jquery.script');
	
	wp_register_script('jquery.Rut', plugins_url('jquery.Rut.js', __FILE__));
	wp_enqueue_script('jquery.Rut');
	
	//script
    wp_register_script('facto_script', plugins_url('factofacturacionelectronica.js', __FILE__));
    wp_enqueue_script('facto_script');
}

//validamos los campos
add_action('woocommerce_checkout_process', 'oml_custom_checkout_field_process');
function oml_custom_checkout_field_process() {
    if ( $_POST['kind_of_legal_invoice'] ) {
		if($_POST['kind_of_legal_invoice']=="fe" || $_POST['kind_of_legal_invoice']=="fee") {
			if(!$_POST['oml_campo_rut']) wc_add_notice( __( 'Debe indicar un RUT.' ), 'error' );
			if(!$_POST['campo_razon_social']) wc_add_notice( __( 'Debe indicar una raz&oacute;n social.' ), 'error' );
			if(!$_POST['campo_giro']) wc_add_notice( __( 'Debe indicar un giro.' ), 'error' );
		}		
	} else wc_add_notice( __( 'Debe indicar un tipo de documento.' ), 'error' );      
	
	if(!$_POST['campo_receptor_direccion']) wc_add_notice( __( 'Debe indicar la direcci&oacute;n del receptor.' ), 'error' );
	if(!$_POST['campo_receptor_comuna']) wc_add_notice( __( 'Debe indicar una comuna.' ), 'error' );
	if(!$_POST['campo_receptor_telefono']) wc_add_notice( __( 'Debe indicar un n&uacute;mero de tel&eacute;fono del receptor.' ), 'error' );
	
}

//recuperamos los valores de los campos
add_action( 'woocommerce_checkout_update_order_meta', 'oml_custom_checkout_field_update_order_meta' );
function oml_custom_checkout_field_update_order_meta( $order_id ) {
	if ( ! empty( $_POST['kind_of_legal_invoice'] ) ) {
        update_post_meta( $order_id, 'Tipo de documento', sanitize_text_field( $_POST['kind_of_legal_invoice'] ) );
    }
	
	if ( ! empty( $_POST['oml_campo_rut'] ) ) {
        update_post_meta( $order_id, 'RUT', sanitize_text_field( $_POST['oml_campo_rut'] ) );
    }
	
	if ( ! empty( $_POST['campo_razon_social'] ) ) {
        update_post_meta( $order_id, 'Raz&oacute;n social', sanitize_text_field( $_POST['campo_razon_social'] ) );
    }
	
	if ( ! empty( $_POST['campo_giro'] ) ) {
        update_post_meta( $order_id, 'Giro', sanitize_text_field( $_POST['campo_giro'] ) );
    }
	
	if ( ! empty( $_POST['campo_receptor_direccion'] ) ) {
        update_post_meta( $order_id, 'campo_receptor_direccion', sanitize_text_field( $_POST['campo_receptor_direccion'] ) );
    }
	
	if ( ! empty( $_POST['campo_receptor_comuna'] ) ) {
        update_post_meta( $order_id, 'campo_receptor_comuna', sanitize_text_field( $_POST['campo_receptor_comuna'] ) );
    }
	
	if ( ! empty( $_POST['campo_receptor_telefono'] ) ) {
        update_post_meta( $order_id, 'campo_receptor_telefono', sanitize_text_field( $_POST['campo_receptor_telefono'] ) );
    }
}

//mostramos los valores en la orden edit page
add_action( 'woocommerce_admin_order_data_after_billing_address', 'oml_custom_checkout_field_display_admin_order_meta', 10, 4 );
add_action( 'woocommerce_order_details_after_order_table', 'oml_custom_checkout_field_display_admin_order_meta', 10, 4 );
function oml_custom_checkout_field_display_admin_order_meta($order){
	echo '<p><strong>'.__('Direcci&oacute;n del receptor').':</strong> ' . get_post_meta( $order->id, 'campo_receptor_direccion', true ) . '</p>';
	echo '<p><strong>'.__('Comuna del receptor').':</strong> ' . get_post_meta( $order->id, 'campo_receptor_comuna', true ) . '</p>';
	echo '<p><strong>'.__('Tel&eacute;fono del receptor').':</strong> ' . get_post_meta( $order->id, 'campo_receptor_telefono', true ) . '</p>';

	
	if(get_post_meta( $order->id, 'Tipo de documento', true ) == "fe")
		echo '<p><strong>'.__('Tipo de documento').':</strong> Factura electr&oacute;nica</p>';
	if(get_post_meta( $order->id, 'Tipo de documento', true ) == "fee")
		echo '<p><strong>'.__('Tipo de documento').':</strong> Factura exenta electr&oacute;nica</p>';
	if(get_post_meta( $order->id, 'Tipo de documento', true ) == "be")
		echo '<p><strong>'.__('Tipo de documento').':</strong> Boleta electr&oacute;nica</p>';
	if(get_post_meta( $order->id, 'Tipo de documento', true ) == "bee")
		echo '<p><strong>'.__('Tipo de documento').':</strong> Boleta exenta electr&oacute;nica</p>';
	
	if(get_post_meta( $order->id, 'Tipo de documento', true ) == "fe" || get_post_meta( $order->id, 'Tipo de documento', true ) == "fee") {
		echo '<p><strong>'.__('RUT').':</strong> ' . get_post_meta( $order->id, 'RUT', true ) . '</p>';
		echo '<p><strong>'.__('Giro').':</strong> ' . get_post_meta( $order->id, 'Giro', true ) . '</p>';
		echo '<p><strong>'.__('Raz&oacute;n social').':</strong> ' . get_post_meta( $order->id, 'Raz&oacute;n social', true ) . '</p>';
	}
}

//genera la pg con la orden
add_action( 'woocommerce_thankyou', 'OML_display_order_data', 20 );
function OML_display_order_data($order_id)
{
	$order = new WC_Order( $order_id );
		
	include_once 'facto.php';
	$data = array();
	$data['order_id'] = $order_id;

	if(get_post_meta( $order_id, 'Tipo de documento', true) == "be") $data['tipo_dte'] = 39;
	else if(get_post_meta( $order_id, 'Tipo de documento', true) == "bee") $data['tipo_dte'] = 41;
	else if(get_post_meta( $order_id, 'Tipo de documento', true) == "fe") $data['tipo_dte'] = 33;
	else if(get_post_meta( $order_id, 'Tipo de documento', true) == "fee") $data['tipo_dte'] = 34;

	$data['fecha_emision'] = date('Y-m-d');

	if($data['tipo_dte'] == 33 || $data['tipo_dte'] == 34) {
		$data['receptor_rut'] = get_post_meta( $order_id, 'RUT', true);
		$data['receptor_razon'] = get_post_meta( $order_id, 'Raz&oacute;n social', true);
		$data['receptor_giro'] = get_post_meta( $order_id, 'Giro', true);
	}
	else {
		$data['receptor_rut'] = "";
		$data['receptor_razon'] = "";
		$data['receptor_giro'] = "";
	}
	
	
	$data['receptor_direccion'] = get_post_meta( $order_id, 'campo_receptor_direccion', true);
	
	$data['receptor_comuna'] = get_post_meta( $order_id, 'campo_receptor_comuna', true);
	//$data['receptor_comuna'] = $nombre_comunas['CL'][get_post_meta( $order_id, '_billing_state', true)];
	//$data['receptor_ciudad'] = get_post_meta( $order_id, '_billing_state', true);
	
	$data['receptor_telefono'] = get_post_meta( $order_id, 'campo_receptor_telefono', true);
	$data['receptor_email'] = get_post_meta( $order_id, '_billing_email', true);
	
	$data['condiciones_pago'] = 0;
	
	$data['orden_compra_num'] = $order->get_order_number();
	$data['orden_compra_fecha'] = $data['fecha_emision'];
	
	$data['cantidad'] = $order->get_item_count();
	
	//detalles
	$detalles = array();
	$total_exento = 0;
	$total_afecto = 0;
	
	$items = $order->get_items();
	foreach ($items as $item) {
		$detalle = array();
		$detalle['cantidad'] = (int)$item['qty'];
		$detalle['unidad'] = ""; //$item['type'];
		$detalle['glosa'] = $item['name'];
		//$detalle['monto_unitario'] = (int)( (int)$item['line_total'] / $detalle['cantidad']  );
		$detalle['descuentorecargo_monto'] = 0;
		$detalle['descuentorecargo_porcentaje'] = 0;
	
		if($data['tipo_dte'] == 34 || $data['tipo_dte'] == 41) {
		  $detalle['monto_unitario'] = round($item['line_total'] / $detalle['cantidad'],6);
			$detalle['exento_afecto'] = 0;
			$total_exento += round($detalle['cantidad'] * $detalle['monto_unitario']);
		} 
		else
		{
		  $detalle['monto_unitario'] = round((($item['line_total']  / $detalle['cantidad']) / 1.19), 6);
			$detalle['exento_afecto'] = 1;
			$total_afecto += round($detalle['cantidad'] * $detalle['monto_unitario']);
		}
	
		array_push($detalles, $detalle);
	}
	
	//GASTOS DE ENVIO
	$gastos_de_envio = $order->get_total_shipping();
	if($gastos_de_envio>0) {
		$detalle = array();
		
		$detalle['cantidad'] = 1;
		$detalle['unidad'] = "uni"; 
		$detalle['glosa'] = "Gastos de envio";
		$detalle['descuentorecargo_monto'] = 0;
		$detalle['descuentorecargo_porcentaje'] = 0;
	
		if($data['tipo_dte'] == 34 || $data['tipo_dte'] == 41) {
			$detalle['monto_unitario'] = round($gastos_de_envio);
			$detalle['exento_afecto'] = 0;
			$total_exento += $detalle['monto_unitario'];
		} 
		else
		{
			$gastos_de_envio = round( ($gastos_de_envio / 1.19), 6);
			$detalle['monto_unitario'] = $gastos_de_envio;
			$detalle['exento_afecto'] = 1;
			$total_afecto += $detalle['monto_unitario'];
		}		
		array_push($detalles, $detalle);
	}
	$data['detalles'] = $detalles;
		
	//totales
	
	$data['total_iva'] = round($total_afecto * 0.19);
	$data['total_exento'] = round($total_exento);
	$data['total_afecto'] = round($total_afecto);
	$data['total_final'] = $data['total_iva'] + $data['total_afecto'] + $data['total_exento']; 
	
	$fact = "manual";				
	if( get_option("facto_".$order->payment_method."_fact")) $fact = get_option("facto_".$order->payment_method."_fact");
	if($fact != "auto" && $fact != "manual") $fact = "manual";
	
	
	//creamos una tabla para guardar el resultado
	global $wpdb;
	/*
		$oml_estado == 0 => factura no generada
		$oml_estado == 1 => factura generada correctamente
		$oml_estado == 2 => factura generada con error
	*/
	$query_create = "
					CREATE TABLE IF NOT EXISTS `oml_facto_order_mp` (
					  `order_id` INT,
						`msg` VARCHAR(255),
					  `fact` VARCHAR(255),
					  `estado` INT,
					  `enlace` VARCHAR(255),
					  `error` TEXT,					  					  
					PRIMARY KEY (`order_id`)
					)";
	$wpdb->query($query_create);
			
	if ($fact == "auto")
	{
	    // Si estamos en modo automático, veamos que el estado del pedido sea pagado
        if ($order->status != "failed")
        {
		  $respuesta = facto($data);
        }
	}
	else
	{
		echo "La factura ser&aacute; emitida por un administrador.";
		//agregamos que la orden es manual
		$data = array(
					'order_id' => $order_id,
					'fact' => 'manual',
					'estado' => 1
		);
		$wpdb->insert( "oml_facto_order_mp",  $data);
	}
}
//END CHECKOUT



// ***********************************
// ***************** ADMIN PAGE ******
add_action('admin_menu', 'register_admin_page');
function register_admin_page() {
	add_submenu_page( 'woocommerce', 'Configuraciones', 'Facto', 'manage_options', 'submenu_configuraciones', 'submenu_configuraciones_callback' );
	add_action( 'admin_init', 'register_facto_settings' );
}

function submenu_configuraciones_callback() {
	if(isset($_REQUEST ["settings-updated"]) && $_REQUEST ["settings-updated"] == true) {
		echo "<script>alert('Se han guardado la nuevas opciones.');</script>";
	}
	?>
	
	<div class="wrap">
	<h2>Facto - configuraciones</h2>
	
	<form method="post" action="options.php" id="facto_formulario">
	    <?php settings_fields( 'facto_settings_group' ); ?>
	    <?php do_settings_sections( 'facto_settings_group' ); ?>
	    <table class="form-table">
	        <tr valign="top">
	        <th scope="row">RUT de vendedor</th>
	        <td><input type="text" name="facto_seller_rut" id="facto_seller_rut" value="<?php echo esc_attr( get_option('facto_seller_rut') ); ?>" /></td>
	        </tr>
	        
	        <tr valign="top">
	        <th scope="row">Webservice user</th>
	        <td><input type="text" name="facto_webservice_user" id="facto_webservice_user" value="<?php echo esc_attr( get_option('facto_webservice_user') ); ?>" /></td>
	        </tr>
	        
	        <tr valign="top">
	        <th scope="row">Webservice pass</th>
	        <td><input type="text" name="facto_webservice_pass" id="facto_webservice_pass" value="<?php echo esc_attr( get_option('facto_webservice_pass') ); ?>" /></td>
	        </tr>
	        
	        <tr valign="top">
	        <th scope="row">Webservice URL</th>
	        <td><input type="text" name="facto_webservice_url" id="facto_webservice_url" value="<?php echo esc_attr( get_option('facto_webservice_url') ); ?>" /></td>
	        </tr>
	        
	        <tr valign="top">
	     	   <th colspan="2">Tipo de documento permitidos</th>
	        </tr>
	        
	        <tr valign="top">
	        	<td>Factura electr&oacute;nica</td>
	        	<td><input type="checkbox" name="facto_checkbox_fe" id="facto_checkbox_fe" value="on" <?php if(esc_attr( get_option('facto_checkbox_fe'))=="on") echo "checked"; ?> /></td>
	        </tr>
	        
	        <tr valign="top">
	        	<td>Factura exenta electr&oacute;nica</td>
	        	<td><input type="checkbox" name="facto_checkbox_fee" id="facto_checkbox_fee" value="on" <?php if(esc_attr( get_option('facto_checkbox_fee'))=="on") echo "checked"; ?> /></td>
	        </tr>
	        
	        <tr valign="top">
	        	<td>Boleta electr&oacute;nica</td>
	        	<td><input type="checkbox" name="facto_checkbox_be" id="facto_checkbox_be" value="on" <?php if(esc_attr( get_option('facto_checkbox_be'))=="on") echo "checked"; ?> /></td>
	        </tr>
	        
	        <tr valign="top">
	        	<td>Boleta exenta electr&oacute;nica</td>
	        	<td><input type="checkbox" name="facto_checkbox_bee" id="facto_checkbox_bee" value="on" <?php if(esc_attr( get_option('facto_checkbox_bee'))=="on") echo "checked"; ?> /></td>
	        </tr>
	    </table>


	</div>
	<?php	
	//RUT
	//wp_register_script('jquery.script', plugins_url('jquery.script.js', __FILE__));
	//wp_enqueue_script('jquery.script');
	
	wp_register_script('jquery.Rut', plugins_url('jquery.Rut.js', __FILE__));
	wp_enqueue_script('jquery.Rut');
	
	//script
	wp_register_script('facto_script_admin', plugins_url('factofacturacionelectronica_admin.js', __FILE__));
	wp_enqueue_script('facto_script_admin');
	
	?>
	<div>
		<h2>M&eacute;todos de pago</h2>
		
		<?php			
			//para cada mp obtenemos su configuración
			if (class_exists("WC"))
			{
			$mp_arr = WC()->payment_gateways->get_available_payment_gateways();
			}
			else
			{
			 $mp_arr = array();    
			}
			
			?><table class="form-table"><?php
			foreach($mp_arr as $mp) {
				$code = $mp->id;
				$title = $mp->title;

				$fact = "manual";				
				if( get_option("facto_".$code."_fact")) $fact = get_option("facto_".$code."_fact");
			
				if($fact != "auto" && $fact != "manual") $fact = "manual";
				
				?>
				<tr valign="top">
					<th scope="row"><?php echo $title; ?></th>
					<td>
						<select name="<?php echo "facto_".$code."_fact"; ?>">
							<option value="auto" <?php if($fact=="auto") echo "selected='selected'"; ?> >Autom&aacute;tica</option>
							<option value="manual" <?php if($fact=="manual") echo "selected='selected'"; ?>>Manual</option>
						</select>
					</td>
				</tr>
				<?php
			}
			
			?> </table> <?php
		?>
	</div>
	
		    <?php submit_button(); ?>
	</form>
	<?php
}

function register_facto_settings() {
	register_setting( 'facto_settings_group', 'facto_seller_rut' );
	register_setting( 'facto_settings_group', 'facto_webservice_user' );
	register_setting( 'facto_settings_group', 'facto_webservice_pass' );
	register_setting( 'facto_settings_group', 'facto_webservice_url' );

	register_setting( 'facto_settings_group', 'facto_checkbox_fe' );
	register_setting( 'facto_settings_group', 'facto_checkbox_fee' );
	register_setting( 'facto_settings_group', 'facto_checkbox_be' );
	register_setting( 'facto_settings_group', 'facto_checkbox_bee' );
	
	//para cada mp obtenemos su configuración
	if (class_exists("WC"))
	{
	$mp_arr = WC()->payment_gateways->get_available_payment_gateways();
	}
	else
	{
	    $mp_arr = array();
	}
	
	foreach($mp_arr as $mp) {
		$code = $mp->id;
		register_setting( 'facto_settings_group', "facto_".$code."_fact" );
	}
}
//END ADMIN PAGE

//*************************************************************************
//********************** COMUNAS ******************************************
/*function comunas_de_chile($states) {
	$states['CL'] = array(
			'100' => 'Algarrobo',
			'101' => 'Alhué',
			'102' => 'Alto Biobío',
			'103' => 'Alto del Carmen',
			'104' => 'Alto Hospicio',
			'105' => 'Ancud',
			'106' => 'Andacollo',
			'107' => 'Angol',
			'108' => 'Antártica',
			'109' => 'Antofagasta',
			'110' => 'Antuco',
			'111' => 'Arauco',
			'112' => 'Arica',
			'113' => 'Aysén',
			'114' => 'Buin',
			'115' => 'Bulnes',
			'116' => 'Cabildo',
			'117' => 'Cabo de Hornos',
			'118' => 'Cabrero',
			'119' => 'Calama',
			'120' => 'Calbuco',
			'121' => 'Caldera',
			'122' => 'Calera de Tango',
			'123' => 'Calle Larga',
			'124' => 'Camarones',
			'125' => 'Camiña',
			'126' => 'Canela',
			'127' => 'Cañete',
			'128' => 'Carahue',
			'129' => 'Cartagena',
			'130' => 'Casablanca',
			'131' => 'Castro',
			'132' => 'Catemu',
			'133' => 'Cauquenes',
			'134' => 'Cerrillos',
			'135' => 'Cerro Navia',
			'136' => 'Chaitén',
			'137' => 'Chanco',
			'138' => 'Chañaral',
			'139' => 'Chépica',
			'140' => 'Chiguayante',
			'141' => 'Chile Chico',
			'142' => 'Chillán',
			'143' => 'Chillán Viejo',
			'144' => 'Chimbarongo',
			'145' => 'Cholchol',
			'146' => 'Chonchi',
			'147' => 'Cisnes',
			'148' => 'Cobquecura',
			'149' => 'Cochamó',
			'150' => 'Cochrane',
			'151' => 'Codegua',
			'152' => 'Coelemu',
			'153' => 'Coihueco',
			'154' => 'Coinco',
			'155' => 'Colbún',
			'156' => 'Colchane',
			'157' => 'Colina',
			'158' => 'Collipulli',
			'159' => 'Coltauco',
			'160' => 'Combarbalá',
			'161' => 'Concepción',
			'162' => 'Conchalí',
			'163' => 'Concón',
			'164' => 'Constitución',
			'165' => 'Contulmo',
			'166' => 'Copiapó',
			'167' => 'Coquimbo',
			'168' => 'Coronel',
			'169' => 'Corral',
			'170' => 'Coyhaique',
			'171' => 'Cunco',
			'172' => 'Curacautín',
			'173' => 'Curacaví',
			'174' => 'Curaco de Vélez',
			'175' => 'Curanilahue',
			'176' => 'Curarrehue',
			'177' => 'Curepto',
			'178' => 'Curicó',
			'179' => 'Dalcahue',
			'180' => 'Diego de Almagro',
			'181' => 'Doñihue',
			'182' => 'El Bosque',
			'183' => 'El Carmen',
			'184' => 'El Monte',
			'185' => 'El Quisco',
			'186' => 'El Tabo',
			'187' => 'Empedrado',
			'188' => 'Ercilla',
			'189' => 'Estación Central',
			'190' => 'Florida',
			'191' => 'Freire',
			'192' => 'Freirina',
			'193' => 'Fresia',
			'194' => 'Frutillar',
			'195' => 'Futaleufú',
			'196' => 'Futrono',
			'197' => 'Galvarino',
			'198' => 'General Lagos',
			'199' => 'Gorbea',
			'200' => 'Graneros',
			'201' => 'Guaitecas',
			'202' => 'Hijuelas',
			'203' => 'Hualaihué',
			'204' => 'Hualañé',
			'205' => 'Hualpén',
			'206' => 'Hualqui',
			'207' => 'Huara',
			'208' => 'Huasco',
			'209' => 'Huechuraba',
			'210' => 'Illapel',
			'211' => 'Independencia',
			'212' => 'Iquique',
			'213' => 'Isla de Maipo',
			'214' => 'Isla de Pascua',
			'215' => 'Juan Fernández',
			'216' => 'La Calera',
			'217' => 'La Cisterna',
			'218' => 'La Cruz',
			'219' => 'La Estrella',
			'220' => 'La Florida',
			'221' => 'La Granja',
			'222' => 'La Higuera',
			'223' => 'La Ligua',
			'224' => 'La Pintana',
			'225' => 'La Reina',
			'226' => 'La Serena',
			'227' => 'La Unión',
			'228' => 'Lago Ranco',
			'229' => 'Lago Verde',
			'230' => 'Laguna Blanca',
			'231' => 'Laja',
			'232' => 'Lampa',
			'233' => 'Lanco',
			'234' => 'Las Cabras',
			'235' => 'Las Condes',
			'236' => 'Lautaro',
			'237' => 'Lebu',
			'238' => 'Licantén',
			'239' => 'Limache',
			'240' => 'Linares',
			'241' => 'Litueche',
			'242' => 'Llanquihue',
			'243' => 'Llay Llay',
			'244' => 'Lo Barnechea',
			'245' => 'Lo Espejo',
			'246' => 'Lo Prado',
			'247' => 'Lolol',
			'248' => 'Loncoche',
			'249' => 'Longaví',
			'250' => 'Lonquimay',
			'251' => 'Los Álamos',
			'252' => 'Los Andes',
			'253' => 'Los Ángeles',
			'254' => 'Los Lagos',
			'255' => 'Los Muermos',
			'256' => 'Los Sauces',
			'257' => 'Los Vilos',
			'258' => 'Lota',
			'259' => 'Lumaco',
			'260' => 'Machalí',
			'261' => 'Macul',
			'262' => 'Máfil',
			'263' => 'Maipú',
			'264' => 'Malloa',
			'265' => 'Marchihue',
			'266' => 'María Elena',
			'267' => 'María Pinto',
			'268' => 'Mariquina',
			'269' => 'Maule',
			'270' => 'Maullín',
			'271' => 'Mejillones',
			'272' => 'Melipeuco',
			'273' => 'Melipilla',
			'274' => 'Molina',
			'275' => 'Monte Patria',
			'276' => 'Mostazal',
			'277' => 'Mulchén',
			'278' => 'Nacimiento',
			'279' => 'Nancagua',
			'280' => 'Natales',
			'281' => 'Navidad',
			'282' => 'Negrete',
			'283' => 'Ninhue',
			'284' => 'Nogales',
			'285' => 'Nueva Imperial',
			'286' => 'Ñiquén',
			'287' => 'Ñuñoa',
			'288' => 'O\'Higgins',
			'289' => 'Olivar',
			'290' => 'Ollagüe',
			'291' => 'Olmué',
			'292' => 'Osorno',
			'293' => 'Ovalle',
			'294' => 'Padre Hurtado',
			'295' => 'Padre las Casas',
			'296' => 'Paihuano',
			'297' => 'Paillaco',
			'298' => 'Paine',
			'299' => 'Palena',
			'300' => 'Palmilla',
			'301' => 'Panguipulli',
			'302' => 'Panquehue',
			'303' => 'Papudo',
			'304' => 'Paredones',
			'305' => 'Parral',
			'306' => 'Pedro Aguirre Cerda',
			'307' => 'Pelarco',
			'308' => 'Pelluhue',
			'309' => 'Pemuco',
			'310' => 'Pencahue',
			'311' => 'Penco',
			'312' => 'Peñaflor',
			'313' => 'Peñalolén',
			'314' => 'Peralillo',
			'315' => 'Perquenco',
			'316' => 'Petorca',
			'317' => 'Peumo',
			'318' => 'Pica',
			'319' => 'Pichidegua',
			'320' => 'Pichilemu',
			'321' => 'Pinto',
			'322' => 'Pirque',
			'323' => 'Pitrufquén',
			'324' => 'Placilla',
			'325' => 'Portezuelo',
			'326' => 'Porvenir',
			'327' => 'Pozo Almonte',
			'328' => 'Primavera',
			'329' => 'Providencia',
			'330' => 'Puchuncaví',
			'331' => 'Pucón',
			'332' => 'Pudahuel',
			'333' => 'Puente Alto',
			'334' => 'Puerto Montt',
			'335' => 'Puerto Octay',
			'336' => 'Puerto Varas',
			'337' => 'Pumanque',
			'338' => 'Punitaqui',
			'339' => 'Punta Arenas',
			'340' => 'Puqueldón',
			'341' => 'Purén',
			'342' => 'Purranque',
			'343' => 'Putaendo',
			'344' => 'Putre',
			'345' => 'Puyehue',
			'346' => 'Queilén',
			'347' => 'Quellón',
			'348' => 'Quemchi',
			'349' => 'Quilaco',
			'350' => 'Quilicura',
			'351' => 'Quilleco',
			'352' => 'Quillón',
			'353' => 'Quillota',
			'354' => 'Quilpué',
			'355' => 'Quinchao',
			'356' => 'Quinta de Tilcoco',
			'357' => 'Quinta Normal',
			'358' => 'Quintero',
			'359' => 'Quirihue',
			'360' => 'Rancagua',
			'361' => 'Ránquil',
			'362' => 'Rauco',
			'363' => 'Recoleta',
			'364' => 'Renaico',
			'365' => 'Renca',
			'366' => 'Rengo',
			'367' => 'Requínoa',
			'368' => 'Retiro',
			'369' => 'Rinconada',
			'370' => 'Río Bueno',
			'371' => 'Río Claro',
			'372' => 'Río Hurtado',
			'373' => 'Río Ibáñez',
			'374' => 'Río Negro',
			'375' => 'Río Verde',
			'376' => 'Romeral',
			'377' => 'Saavedra',
			'378' => 'Sagrada Familia',
			'379' => 'Salamanca',
			'380' => 'San Antonio',
			'381' => 'San Bernardo',
			'382' => 'San Carlos',
			'383' => 'San Clemente',
			'384' => 'San Esteban',
			'385' => 'San Fabián',
			'386' => 'San Felipe',
			'387' => 'San Fernando',
			'388' => 'San Gregorio',
			'389' => 'San Ignacio',
			'390' => 'San Javier',
			'391' => 'San Joaquín',
			'392' => 'San José de Maipo',
			'393' => 'San Juan de la Costa',
			'394' => 'San Miguel',
			'395' => 'San Nicolás',
			'396' => 'San Pablo',
			'397' => 'San Pedro',
			'398' => 'San Pedro de Atacama',
			'399' => 'San Pedro de la Paz',
			'400' => 'San Rafael',
			'401' => 'San Ramón',
			'402' => 'San Rosendo',
			'403' => 'San Vicente',
			'404' => 'Santa Bárbara',
			'405' => 'Santa Cruz',
			'406' => 'Santa Juana',
			'407' => 'Santa María',
			'408' => 'Santiago',
			'409' => 'Santo Domingo',
			'410' => 'Sierra Gorda',
			'411' => 'Talagante',
			'412' => 'Talca',
			'413' => 'Talcahuano',
			'414' => 'Taltal',
			'415' => 'Temuco',
			'416' => 'Teno',
			'417' => 'Teodoro Schmidt',
			'418' => 'Tierra Amarilla',
			'419' => 'Tiltil',
			'420' => 'Timaukel',
			'421' => 'Tirúa',
			'422' => 'Tocopilla',
			'423' => 'Toltén',
			'424' => 'Tomé',
			'425' => 'Torres del Paine',
			'426' => 'Tortel',
			'427' => 'Traiguén',
			'428' => 'Treguaco',
			'429' => 'Tucapel',
			'430' => 'Valdivia',
			'431' => 'Vallenar',
			'432' => 'Valparaíso',
			'433' => 'Vichuquén',
			'434' => 'Victoria',
			'435' => 'Vicuña',
			'436' => 'Vilcún',
			'437' => 'Villa Alegre',
			'438' => 'Villa Alemana',
			'439' => 'Villarrica',
			'440' => 'Viña del Mar',
			'441' => 'Vitacura',
			'442' => 'Yerbas Buenas',
			'443' => 'Yumbel',
			'444' => 'Yungay',
			'445' => 'Zapallar'
	); 
	return $states;
}*/
//add_filter('woocommerce_states', 'comunas_de_chile');

//mostramos la factura
add_action( 'woocommerce_admin_order_data_after_billing_address', 'oml_facto_factura_admin' );
function oml_facto_factura_admin($order) {
		/*
			$oml_estado == 0 => factura emitida y enviada
			$oml_estado == 1 => factura no generada
			$oml_estado == 2 => factura generada pero no enviada
		*/
		
		global $wpdb;
		$resultado = $wpdb->get_row( "SELECT fact, estado, msg, enlace FROM oml_facto_order_mp WHERE order_id = ".$order->id );
		if($resultado){
	?>
		<input type="hidden" name="oml_order_id" id="oml_order_id" value="<?php echo $order->id; ?>" />
		
		<h4>Facturaci&oacute;n</h4>
			<?php
				$estado = $resultado->estado;
				$msg = $resultado->msg;
				$enlace = $resultado->enlace;
				
				if($enlace == ''){
					//print "<a href='javascript:facturar(".$this->getOrder()->getId().")' id='btn_oml_estado'>Generar la factura</a>";	
					//$aer = plugin_dir_path( __FILE__ );
					//var_dump ($aer);
					echo " <a href='javascript:facturar(\"".plugin_dir_path( __FILE__ )."\");' id='btn_oml_estado'>Generar factura</a>";
					
					//print "<span id='ajax_loader' style='display:none'><img src='".$this->getSkinUrl('images/opc-ajax-loader.gif')."'/></span>";
					
					echo "<p id='p_oml_estado'>".$msg."</p>";
				}
				else
				{
					print "Puede ver la factura en el siguiente <a href='".$enlace."' target='_blank'>enlace</a>";
				}
			?>
			
	<?php
	
		//wp_register_script('jquery.script', plugins_url('jquery.script.js', __FILE__));
		//wp_enqueue_script('jquery.script');
		
		wp_register_script('oml_facto_admin_order', plugins_url('oml_facto_admin_order.js', __FILE__));
		wp_enqueue_script('oml_facto_admin_order');
			
		}
}

add_action( 'woocommerce_order_details_after_order_table', 'oml_facto_factura' );
function oml_facto_factura($order) {
	/*
		$oml_estado == 0 => factura no emitida
		$oml_estado == 1 => factura emitida correctamente
		$oml_estado == 2 => factura emitida con error
	*/
		
		global $wpdb;
		$resultado = $wpdb->get_row( "SELECT fact, estado, enlace FROM oml_facto_order_mp WHERE order_id = ".$order->id );
		if($resultado) {
		
	?>
		<div>
			<h3>Facturaci&oacute;n</h3>
			<?php
				if($resultado->estado == 0) {
					echo "Documento generado y enviado al SII. <a href='".$resultado->enlace."' target='_blank'>enlace</a>";				
				}
				else if($resultado->estado == 1) {
					echo "Se ha producido un error al generar la factura.";
				}
				else if ($resultado->estado == 2)
				{
					echo "El documento se generó como borrador pero no se ha podido enviar al SII. Ingrese a Facto para resolver esta situación.";
					
					if ($resultado->enlace != "")
					{
					   print "<a href='".$resultado->enlace."' target='_blank'>enlace</a>";   
					}
					
				}
				else 
				{
					echo "Ha ocurrido un error inesperado.";
				}
			?>
		</div>
	<?php
	}
}

/*
add_filter('woocommerce_email_order_meta_keys', 'my_custom_order_meta_keys');
function my_custom_order_meta_keys( $keys ) {
     //slaente si hay enlace a la factura lo mandamos por email.
	 $keys[] = 'Tracking Code'; // This will look for a custom field called 'Tracking Code' and add it to emails
     return $keys;
}
*/
?>