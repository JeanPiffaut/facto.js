document.getElementById("kind_of_legal_invoice").onchange = function(){factofacturacionelectronica_cambiar();};

function factofacturacionelectronica_cambiar(){
	var obj = document.getElementById("kind_of_legal_invoice");
	document.getElementById("factofacturacionelectronica_div_factura").style.display = "none";

	if(obj.value=="fe" || obj.value=="fee") {
		
		document.getElementById("factofacturacionelectronica_div_factura").style.display = "block";
	}
	else {
		document.getElementById("campo_rut").value = "";
		document.getElementById("campo_razon_social").value = "";
		document.getElementById("campo_giro").value = "";
	}
}

jQuery('#oml_campo_rut').Rut({
    on_error: function(){
        alert('El rut ingresado es incorrecto');jQuery('#oml_campo_rut').val('');jQuery('#oml_campo_rut').focus(); 
    }, 
       format_on: 'keyup' 
});

jQuery( document ).ready(function() {
	factofacturacionelectronica_cambiar();
});