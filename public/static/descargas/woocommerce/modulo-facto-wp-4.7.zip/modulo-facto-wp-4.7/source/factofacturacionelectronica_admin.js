jQuery('#facto_seller_rut').Rut({
    on_error: function(){
        alert('El rut ingresado es incorrecto');jQuery('#facto_seller_rut').val('');jQuery('#facto_seller_rut').focus(); 
    }, 
       format_on: 'keyup' 
});

function seleccionar_tipo(obj) {
	//todas false
	if(jQuery('#facto_checkbox_fe').is(':checked') == false && jQuery('#facto_checkbox_fee').is(':checked') == false && jQuery('#facto_checkbox_be').is(':checked') == false && jQuery('#facto_checkbox_bee').is(':checked') == false) {
		jQuery("#"+obj.id).prop("checked", true);
	}
}

function validar_formulario(){
	var valido = true;
	
	if(jQuery("#facto_seller_rut").val() == "") {
		alert("Debe ingresar el campo Seller RUT.");
		valido = false
	}
	else if(jQuery("#facto_webservice_user").val() == "") {
		alert("Debe ingresar el campo Webservice user.");
		valido = false
	}
	else if(jQuery("#facto_webservice_pass").val() == "") {
		alert("Debe ingresar el campo Webservice pass.");
		valido = false
	}
	else if(jQuery("#facto_webservice_url").val() == "") {
		alert("Debe ingresar el campo Webservice url.");
		valido = false
	}
	
	//por lo menos un tipo de documento
	else if(jQuery('#facto_checkbox_fe').is(':checked') == false && jQuery('#facto_checkbox_fee').is(':checked') == false && jQuery('#facto_checkbox_be').is(':checked') == false && jQuery('#facto_checkbox_bee').is(':checked') == false) {
		valido = false;
	}
}

document.getElementById("facto_checkbox_fe").onclick = function(){seleccionar_tipo(this);};
document.getElementById("facto_checkbox_fee").onclick = function(){seleccionar_tipo(this);};
document.getElementById("facto_checkbox_be").onclick = function(){seleccionar_tipo(this);};
document.getElementById("facto_checkbox_bee").onclick = function(){seleccionar_tipo(this);};

document.getElementById("facto_formulario").onsubmit = function(){return validar_formulario();};