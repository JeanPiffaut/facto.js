<?php
	function facto($data)
	{
	    
	    global $wpdb;
	    
		$tipo_dte = $data["tipo_dte"];
		$fecha_emision = $data["fecha_emision"];
		$receptor_rut = str_replace(".", "", $data["receptor_rut"]);
		$receptor_razon = $data["receptor_razon"];
		$receptor_direccion = $data["receptor_direccion"];
		$receptor_comuna = $data["receptor_comuna"];
		//$receptor_ciudad = $data["receptor_ciudad"];
		$receptor_telefono = $data["receptor_telefono"];
		$receptor_giro = $data["receptor_giro"];
		$condiciones_pago = '0';
		$receptor_email = $data["receptor_email"];
		$orden_compra_num = $data["orden_compra_num"];
		$orden_compra_fecha = $data["orden_compra_fecha"];
		
		$order_id = $data["order_id"];     
		
		/*
		$cantidad= $data['detalles'][0]["cantidad"];
		$unidad= $data['detalles'][0]["unidad"];
		$glosa= $data['detalles'][0]["glosa"];
		$monto_unitario= $data['detalles'][0]["monto_unitario"];
		$exento_afecto= $data['detalles'][0]["exento_afecto"];
		$descuentorecargo_monto= $data['detalles'][0]["descuentorecargo_monto"];
		$descuentorecargo_porcentaje= $data['detalles'][0]["descuentorecargo_porcentaje"];
		/*
		
		/*
		$docreferencia_tipo= $data["docreferencia_tipo"];
		$docreferencia_folio= $data["docreferencia_folio"];
		$codigo_referencia= $data["codigo_referencia"];
		$descripcion= $data["descripcion"];
		*/
		
		$descuentorecargo_global_tipo= '0';
		$descuentorecargo_global_valor= '0';
		$total_exento= $data["total_exento"];
		$total_afecto= $data["total_afecto"];
		$total_iva= $data["total_iva"];
		$total_final= $data["total_final"];
		
		$detalles = $data['detalles'];
		
		require_once(dirname(__FILE__)."/nusoap/nusoap.php");
		 
		try {
		    
		    $consulta = "SELECT enlace, estado FROM oml_facto_order_mp
	    WHERE order_id = '".$order_id."' AND enlace <> ''";
		    
		    $result = $wpdb->get_results ( $consulta );
		        
		    //var_dump($result);
		    //var_dump($consulta);
		    
		    if (count($result) != 0) 
		    {
				print "El documento se ha generado correctamente.<br /><input type='button' style=\"font-size: 15px;border: 1px solid black;padding: 5px;\" onclick=\"window.open('".$result["enlace"]."','_blank');\" value=\"DESCARGA TU BOLETA / FACTURA AQUI\" />";
		    
		        return;
		    }
		    
		    
		    
			$client = new nusoap_client(get_option('facto_webservice_url'));
			$client->setCredentials(get_option('facto_webservice_user'), get_option('facto_webservice_pass'), "basic");
										
			$cadena_xml = "
					<documento xsi:type='urn:emitir_dte'>
						<encabezado xsi:type='urn:encabezado'>
							<tipo_dte xsi:type='xsd:string'>".$tipo_dte."</tipo_dte>
							<fecha_emision xsi:type='xsd:date'>".$fecha_emision."</fecha_emision>
							<receptor_rut xsi:type='xsd:string'>".$receptor_rut."</receptor_rut>
							<receptor_razon xsi:type='xsd:string'><![CDATA[".utf8_decode($receptor_razon)."]]></receptor_razon>
							<receptor_direccion xsi:type='xsd:string'><![CDATA[".utf8_decode($receptor_direccion)."]]></receptor_direccion>
							<receptor_comuna xsi:type='xsd:string'><![CDATA[".utf8_decode($receptor_comuna)."]]></receptor_comuna>
							<receptor_ciudad xsi:type='xsd:string'><![CDATA[".utf8_decode($receptor_ciudad)."]]></receptor_ciudad>

							<receptor_telefono xsi:type='xsd:string'><![CDATA[".utf8_decode($receptor_telefono)."]]></receptor_telefono>
							<receptor_giro xsi:type='xsd:string'><![CDATA[".utf8_decode($receptor_giro)."]]></receptor_giro>
							<condiciones_pago xsi:type='xsd:string'><![CDATA[".utf8_decode($condiciones_pago)."]]></condiciones_pago>
							<receptor_email xsi:type='xsd:string'><![CDATA[".utf8_decode($receptor_email)."]]></receptor_email>
							<orden_compra_num xsi:type='xsd:string'>".$orden_compra_num."</orden_compra_num>
							<orden_compra_fecha xsi:type='xsd:date'>".$orden_compra_fecha."</orden_compra_fecha>
						</encabezado>
									
						<detalles xsi:type='urn:detalles'>";
			foreach ($data['detalles'] as $key => $detalle){
				$cadena_xml .= "
							<detalle xsi:type='urn:detalle'>
								<cantidad xsi:type='xsd:int'>".$detalle['cantidad']."</cantidad>
								<unidad xsi:type='xsd:string'>unid</unidad> 
								<glosa xsi:type='xsd:string'><![CDATA[".utf8_decode($detalle['glosa'])."]]></glosa>
								<monto_unitario xsi:type='xsd:decimal'>".$detalle['monto_unitario']."</monto_unitario>
								<exento_afecto xsi:type='xsd:boolean'>".$detalle['exento_afecto']."</exento_afecto>
							</detalle>";
			}
			
			$cadena_xml .= "
						</detalles>
					
						<totales xsi:type='urn:totales'>	
							<total_exento xsi:type='xsd:int'>".$total_exento."</total_exento>
							<total_afecto xsi:type='xsd:int'>".$total_afecto."</total_afecto>
							<total_iva xsi:type='xsd:int'>".$total_iva."</total_iva>
							<total_final xsi:type='xsd:int'>".$total_final."</total_final>
						</totales>
					</documento>";			
						
			$client->soap_defencoding = 'UTF-8';
			$client->decode_utf8 = false;
			$response = $client->call("emitirDocumento", $cadena_xml);
			$err = $client->getError();

//var_dump($response);
//var_dump($client->request);		
//var_dump($err);
//var_dump($client);
			

			$query_create = "CREATE TABLE IF NOT EXISTS `oml_facto_log` (
						  `id_envio` int(11) NOT NULL AUTO_INCREMENT,
						  `fecha` date,
						  `request` text,
						  `response` text,
						  `estado_envio` int(11),
						  PRIMARY KEY (`id_envio`)
 						)";
			$wpdb->query($query_create);
			
			$data = array(
					'fecha' => $fecha_emision,
					'request' => $client->request,
					'response' => print_r($response, true),
					'estado_envio' => $response["resultado"]["status"]
			);
			$wpdb->insert( "oml_facto_log",  $data);
			
				if($err != "") {
					echo "Ha ocurrido un error al generar el documento.";
					echo "<br><br>";
					echo $err;
					
					$msg = $err;
					$enlace = "";
					$estado = 1;
				}
				else if($response["resultado"]["status"] == 0 || $response["resultado"]["status"] == 2) {
					$estado = $response["resultado"]["status"];
					$msg = $response["resultado"]["mensaje_error"];
					
					if($response["enlaces"]["dte_pdf"]){
						$enlace = $response["enlaces"]["dte_pdf"];
						print "El documento se ha generado correctamente.<br /><input type='button' style=\"font-size: 15px;border: 1px solid black;padding: 5px;\" onclick=\"window.open('".$response["enlaces"]["dte_pdf"]."','_blank');\" value=\"Descarga tu boleta o factura aquí\" />";
						
						/*
						$headers = 'From: Tienda online <noresponder@facto.cl> \r\n';
						$message = "Estimado cliente:\r\n\r\n
									Se ha realizado una orden de compra en nuestro sitio web y se ha emitido el documento correspondiente utilizando FACTO.\r\n\r\n
									El documento lo puede ver siguiendo el enlace:\r\n\r\n

									".$response['enlaces']['dte_pdf']."\r\n\r\n

									Saldos cordiales.";
						wp_mail( $receptor_email, 'FACTURA', $message, $headers );
						*/
						//$estado = 3;
					}
					else{
						print "Documento generado, pero no se cuenta con un pdf.";
						
						$enlace = "";
					}			
					
				}
				else if($response["resultado"]["status"] == 1 )
				{
					print $response["resultado"]["mensaje_error"];
					$msg = $response["resultado"]["mensaje_error"];    
					$estado = 1;
					$enlace = $response["enlaces"]["dte_pdf"];
				}
				
				$data = array(
								'order_id' => $order_id,
								'estado' => $estado,
				                'enlace' => $enlace, 
								'msg' => $msg
				);
					
				$wpdb->insert( "oml_facto_order_mp",  $data);
				
				return true;
			}
		catch (Exception $e)
		{
		    //var_dump($e);
		    
			echo "- Ha ocurrido un error al generar el documento.";
			$data = array(
							'order_id' => $order_id,
							'fact' => 'auto',
							'estado' => 1,
			                'error' => print_r($e,true), 
							'msg' => "Exception"
				);
				$wpdb->insert( "oml_facto_order_mp",  $data);
			return false;
		}
	}
?>