﻿<?php
	require_once("../../../wp-load.php");

	global $wpdb;
	
$error = false;
	
	$data = array();
	$data['order_id'] = $_POST['oml_order_id'];; 
	$order_id = $data['order_id'];
	$order = new WC_Order( $order_id );
	
	

	// Veamos si ya tenemos guardada una URL para esta factura, la utilizamos
	
	$result = $wpdb->get_results ( "SELECT msg, enlace FROM oml_facto_order_mp
	    WHERE order_id = '".$order_id."' AND enlace <> ''" );
	
	//var_dump($result);
	
	if (count($result) != 0)
	{
        $retorno["data"] = $result[0]->enlace;
        $retorno["error"] = false;
        echo json_encode($retorno, JSON_FORCE_OBJECT);
        
        exit();
	}
	
	//exit();
	
	
	if(get_post_meta( $order_id, 'Tipo de documento', true) == "be") $data['tipo_dte'] = 39;
	else if(get_post_meta( $order_id, 'Tipo de documento', true) == "bee") $data['tipo_dte'] = 41;
	else if(get_post_meta( $order_id, 'Tipo de documento', true) == "fe") $data['tipo_dte'] = 33;
	else if(get_post_meta( $order_id, 'Tipo de documento', true) == "fee") $data['tipo_dte'] = 34;

	$data['fecha_emision'] = date('Y-m-d');

	if($data['tipo_dte'] == 33 || $data['tipo_dte'] == 34) {
		$data['receptor_rut'] = get_post_meta( $order_id, 'RUT', true);
		$data['receptor_razon'] = get_post_meta( $order_id, 'Raz&oacute;n social', true);
		$data['receptor_giro'] = get_post_meta( $order_id, 'Giro', true);
	}
	else {
		$data['receptor_rut'] = "";
		$data['receptor_razon'] = "";
		$data['receptor_giro'] = "";
	}
	
	
	$data['receptor_direccion'] = get_post_meta( $order_id, 'campo_receptor_direccion', true);
	$data['receptor_comuna'] = get_post_meta( $order_id, 'campo_receptor_comuna', true);
	//$data['receptor_comuna'] = $nombre_comunas['CL'][get_post_meta( $order_id, '_billing_state', true)];
	//$data['receptor_ciudad'] = get_post_meta( $order_id, '_billing_state', true);
	
	$data['receptor_telefono'] = get_post_meta( $order_id, 'campo_receptor_telefono', true);
	$data['receptor_email'] = get_post_meta( $order_id, '_billing_email', true);
	
	$data['condiciones_pago'] = 0;
	
	$data['orden_compra_num'] = $order->get_order_number();
	$data['orden_compra_fecha'] = $data['fecha_emision'];
	
	$data['cantidad'] = $order->get_item_count();
	
	//detalles
	$detalles = array();
	$total_exento = 0;
	$total_afecto = 0;
	
	$items = $order->get_items();
	foreach ($items as $item) {
		$detalle = array();
		$detalle['cantidad'] = (int)$item['qty'];
		$detalle['unidad'] = ""; //$item['type'];
		$detalle['glosa'] = $item['name'];
		//$detalle['monto_unitario'] = round(number_format((((int)$item['line_total'] / $detalle['cantidad']  ) / 1.19), 6, "." , "")) ;
		$detalle['descuentorecargo_monto'] = 0;
		$detalle['descuentorecargo_porcentaje'] = 0; 
	
	if($data['tipo_dte'] == 34 || $data['tipo_dte'] == 41) {
		   $detalle['monto_unitario'] = round($item['line_total'] / $detalle['cantidad'],6);
			$detalle['exento_afecto'] = 0;
			$total_exento += round($detalle['cantidad'] * $detalle['monto_unitario']);
		} 
		else
		{
		 $detalle['monto_unitario'] = round((($item['line_total']  / $detalle['cantidad']) / 1.19), 6);
			$detalle['exento_afecto'] = 1;
			$total_afecto += round($detalle['cantidad'] * $detalle['monto_unitario']);
		}
	
		array_push($detalles, $detalle);
	}
	
	//GASTOS DE ENVIO
	$gastos_de_envio = $order->get_total_shipping();
	if($gastos_de_envio>0) {
		$detalle = array();
	
		
		$detalle['cantidad'] = 1; 
		$detalle['unidad'] = "";
		$detalle['glosa'] = "Gastos de envio";
		$detalle['descuentorecargo_monto'] = 0;
		$detalle['descuentorecargo_porcentaje'] = 0;
	
		if($data['tipo_dte'] == 34 || $data['tipo_dte'] == 41) {
			$detalle['monto_unitario'] = round($gastos_de_envio); 
			$detalle['exento_afecto'] = 0;
			$total_exento += $detalle['monto_unitario'];
		} 
		else {
			$gastos_de_envio = round( ($gastos_de_envio / 1.19), 6);
			$detalle['monto_unitario'] = $gastos_de_envio;
			$detalle['exento_afecto'] = 1;
			$total_afecto += $detalle['monto_unitario'];
		}		
		array_push($detalles, $detalle);
	}
	$data['detalles'] = $detalles;
		
	//totales
	
	$data['total_iva'] = round($total_afecto * 0.19);
	$data['total_exento'] = round($total_exento);
	$data['total_afecto'] = round($total_afecto);
	$data['total_final'] = $data['total_iva'] + $data['total_afecto'] + $data['total_exento'];
	
	$tipo_dte = $data["tipo_dte"];
	$fecha_emision = $data["fecha_emision"];
	$receptor_rut = str_replace(".", "", $data["receptor_rut"]);
	$receptor_razon = $data["receptor_razon"];
	$receptor_direccion = $data["receptor_direccion"];
	$receptor_comuna = $data["receptor_comuna"];
	//$receptor_ciudad = $data["receptor_ciudad"];
	$receptor_telefono = $data["receptor_telefono"];
	$receptor_giro = $data["receptor_giro"];
	$condiciones_pago = '0';
	$receptor_email = $data["receptor_email"];
	$orden_compra_num = $data["orden_compra_num"];
	$orden_compra_fecha = $data["orden_compra_fecha"];
	
	$order_id = $data["order_id"];
	
	$descuentorecargo_global_tipo= '0';
	$descuentorecargo_global_valor= '0';
	$total_exento= $data["total_exento"];
	$total_afecto= $data["total_afecto"];
	$total_iva= $data["total_iva"];
	$total_final= $data["total_final"];
	
	$detalles = $data['detalles'];

	 
	
    $retorno = array();
	require_once("nusoap/nusoap.php");
	
	try {			
		$client = new nusoap_client(get_option('facto_webservice_url'));
		$client->setCredentials(get_option('facto_webservice_user'), get_option('facto_webservice_pass'), "basic");
		
		$cadena_xml = "
				<documento xsi:type='urn:emitir_dte'>
					<encabezado xsi:type='urn:encabezado'>
						<tipo_dte xsi:type='xsd:string'>".$tipo_dte."</tipo_dte>
						<fecha_emision xsi:type='xsd:date'>".$fecha_emision."</fecha_emision>
						<receptor_rut xsi:type='xsd:string'>".$receptor_rut."</receptor_rut>
						<receptor_razon xsi:type='xsd:string'><![CDATA[".utf8_decode($receptor_razon)."]]></receptor_razon>
						<receptor_direccion xsi:type='xsd:string'><![CDATA[".utf8_decode($receptor_direccion)."]]></receptor_direccion>
						<receptor_comuna xsi:type='xsd:string'><![CDATA[".utf8_decode($receptor_comuna)."]]></receptor_comuna>
						<receptor_ciudad xsi:type='xsd:string'><![CDATA[".utf8_decode($receptor_ciudad)."]]></receptor_ciudad>

						<receptor_telefono xsi:type='xsd:string'><![CDATA[".utf8_decode($receptor_telefono)."]]></receptor_telefono>
						<receptor_giro xsi:type='xsd:string'><![CDATA[".utf8_decode($receptor_giro)."]]></receptor_giro>
						<condiciones_pago xsi:type='xsd:string'><![CDATA[".utf8_decode($condiciones_pago)."]]></condiciones_pago>
						<receptor_email xsi:type='xsd:string'><![CDATA[".utf8_decode($receptor_email)."]]></receptor_email>
						<orden_compra_num xsi:type='xsd:string'>".$orden_compra_num."</orden_compra_num>
						<orden_compra_fecha xsi:type='xsd:date'>".$orden_compra_fecha."</orden_compra_fecha>
					</encabezado>
								
					<detalles xsi:type='urn:detalles'>";
		foreach ($data['detalles'] as $key => $detalle){
			$cadena_xml .= "
						<detalle xsi:type='urn:detalle'>
							<cantidad xsi:type='xsd:int'>".$detalle['cantidad']."</cantidad>
							<unidad xsi:type='xsd:string'>".substr($detalle['unidad'], 0, 3)."</unidad>
							<glosa xsi:type='xsd:string'><![CDATA[".utf8_decode($detalle['glosa'])."]]></glosa>
							<monto_unitario xsi:type='xsd:decimal'>".$detalle['monto_unitario']."</monto_unitario>
							<exento_afecto xsi:type='xsd:boolean'>".$detalle['exento_afecto']."</exento_afecto> 
						</detalle>";
		}
		
		$cadena_xml .= "
					</detalles>
				
					<totales xsi:type='urn:totales'>	
						<total_exento xsi:type='xsd:int'>".$total_exento."</total_exento>
						<total_afecto xsi:type='xsd:int'>".$total_afecto."</total_afecto>
						<total_iva xsi:type='xsd:int'>".$total_iva."</total_iva>
						<total_final xsi:type='xsd:int'>".$total_final."</total_final>
					</totales>
				</documento>";			

		$client->soap_defencoding = 'UTF-8';
		$client->decode_utf8 = false;
		$response = $client->call("emitirDocumento", $cadena_xml);
		$err = $client->getError();

//var_dump($err);
//var_dump($response);
//var_dump($cadena_xml);

//var_dump($client);
		
		//LOG

		$query_create = "CREATE TABLE IF NOT EXISTS `oml_facto_log` (
					  `id_envio` int(11) NOT NULL AUTO_INCREMENT,
					  `fecha` date,
					  `request` text,
					  `response` text,
					  `estado_envio` int(11),
					  PRIMARY KEY (`id_envio`)
					)";
		$wpdb->query($query_create);
		
		$data = array(
				'fecha' => $fecha_emision,
				'request' => $client->request,
				'response' => print_r($response, true),
				'estado_envio' => $response["resultado"]["status"]
		);
		$wpdb->insert( "oml_facto_log",  $data);
		//var_dump($response);
		
				if($err)
				{
					$error = true;
					$retorno['data'] = $err;
					
					$msg = $err;
					$estado = 1;
					$enlace = "";
				}
				else if($response["resultado"]["status"] == 0 || $response["resultado"]["status"] == 2)
				{
					$error = false;
					$estado = $response["resultado"]["status"];
					$enlace = $response["enlaces"]["dte_pdf"];
					
					if($enlace != ""){
						
					    /*
						
						$headers = 'From: e-commerce <no-reply@facto.cl> \r\n';
						$message = "Estimado cliente:\r\n\r\n
										Se ha realizado una orden de compra en nuestro E-COMMERCE y se ha emitido el documento correspondiente utilizando FACTO.\r\n\r\n
										El documento lo puede ver siguiendo el enlace:\r\n\r\n

										".$response['enlaces']['dte_pdf']."\r\n\r\n

										Saludos cordiales. ";
						wp_mail( $receptor_email, 'FACTURA', $message, $headers );
						*/
						$retorno['data'] = $enlace;
					}
					else
					{
						$error = true;
						$msg = $response["resultado"]["mensaje_error"];
						$retorno['data'] = $msg;
					}			
					
				}
				else if($response["resultado"]["status"] == 1 )
				{
					$msg = $response["resultado"]["mensaje_error"];
					$enlace = "";
					$retorno['data'] = $msg;
					$estado = $response["resultado"]["status"];
				}
				
				$data = array(
								'estado' => $estado,
				                'enlace' => $enlace,
								'msg' => $msg
				);
				
				$wpdb->update( "oml_facto_order_mp", $data, array( 'order_id' => $order_id ));
	}
	catch (Exception $e)
	{
		//var_dump($e);
		$error = true;
		$retorno['data'] = $e;
		$query = "UPDATE oml_facto_order_mp SET estado=1,error='".addslashes(print_r($e,true))."' msg='".$retorno['data']."' WHERE order_id=".$order_id;
		$wpdb->query($query);
		
		
	}
	
	if($error) {
		$retorno['error'] = "true";
	} else $retorno['error'] = "false";

	echo json_encode($retorno, JSON_FORCE_OBJECT);
?>