function facturar(){
	 jQuery.ajax({
		 url: "../wp-content/plugins/source/factofacturar.php",
		 method: "POST", 
		 data: {
				'oml_order_id': jQuery('#oml_order_id').val(),
				},
		 contentType: "application/x-www-form-urlencoded; charset=UTF-8",

		 success: function(html) {
			 console.log(html);
			 var retorno = JSON.parse(html);

			 console.log(html);
				if(retorno.error == "true") {
					jQuery('#p_oml_estado').html("Se ha producido un error al generar la factura.<br>Error: "+retorno.data);
					jQuery('#btn_oml_estado').html('Generar factura');
					jQuery('#btn_oml_estado').hide();
					//$('#btn_oml_estado').bind('click', true);
				} else {
					jQuery('#btn_oml_estado').hide();
					jQuery('#p_oml_estado').html("<p id='p_oml_estado'>La factura la puede ver siguiendo el <a href='"+retorno.data+"' target='new'>enlace</a></p>");
				}
			},
			beforeSend: function() {
				jQuery('#btn_oml_estado').html('Cargando...');
				jQuery('#btn_oml_estado').bind('click', false);
			},
			error: function(xhr, ajaxOptions, thrownError) {
				alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
			}
	});
}