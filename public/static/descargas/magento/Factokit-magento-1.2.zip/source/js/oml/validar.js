//alert("asd");

Validation.add('validar-tipo', 'Por lo menos un tipo debe ser seleccionado.', function(v, elm) {
	
	var fe = document.getElementById('facto_tipo_documentos_tipo_dte_fe').value;
	var fee = document.getElementById('facto_tipo_documentos_tipo_dte_fee').value;
	var be = document.getElementById('facto_tipo_documentos_tipo_dte_be').value;
	var bee = document.getElementById('facto_tipo_documentos_tipo_dte_bee').value;
	
	if(fe==0 && fee==0 && be==0 && bee==0) return false;
    return true;
});

jQuery(document).ready(function() {
	if(jQuery('#facto_webservice_RUT_vendedor').length ) {
		jQuery('#facto_webservice_RUT_vendedor').Rut({
		on_error: function(){
			alert('El rut ingresado es incorrecto. Formato sin puntos y con guión. Ejemplo: 12345678-5');jQuery('#facto_webservice_RUT_vendedor').val('');jQuery('#facto_webservice_RUT_vendedor').focus(); 
		},
       format_on: 'keyup' 
	});
	}
});