function facto_cambiar(){
	var obj = document.getElementById("billing:facto_tipo");
		
	if(obj.value=="fe" || obj.value=="fee") {
		document.getElementById("billing:facto_rut").className = "input-text required-entry validar-rut";
		document.getElementById("billing:facto_razonsocial").className = "input-text required-entry";
		document.getElementById("billing:facto_giro").className = "input-text required-entry";
		
		document.getElementById("facto_div_factura").style.display = "block";
	}
	else {
		document.getElementById("billing:facto_rut").className = "input-text";
		document.getElementById("billing:facto_razonsocial").className = "input-text";
		document.getElementById("billing:facto_giro").className = "input-text";
		
		document.getElementById("facto_div_factura").style.display = "none";
	}
}

function btn_billing_form_click() {
	var obj = document.getElementById("billing:facto_tipo");
	
	if(obj.value=="be" || obj.value=="bee") {
		document.getElementById("billing:facto_rut").value = "";
		document.getElementById("billing:facto_razonsocial").value = "";
		document.getElementById("billing:facto_giro").value = "";
	}
	
	billing.save();	
}

j(document).ready(function() {
	//alert('asd');
	facto_cambiar();
}); 

//VALIDAR RUT
Validation.add('validar-rut', 'El rut ingresado es incorrecto.', function(v, elm) {
	var rut = document.getElementById('billing:facto_rut').value;
	
	if (rut.toString().trim() != '')
	{
		if (rut.toString().indexOf('-') > 0) {
			var caracteres = new Array();
			var serie = new Array(2, 3, 4, 5, 6, 7);
			var dig = rut.toString().substr(rut.toString().length - 1, 1);
			rut = rut.toString().substr(0, rut.toString().length - 2);
		 
	        for (var i = 0; i < rut.length; i++) {
	            caracteres[i] = parseInt(rut.charAt((rut.length - (i + 1))));
	        }
		 
	        var sumatoria = 0;
	        var k = 0;
	        var resto = 0;
	 
	        for (var j = 0; j < caracteres.length; j++) {
	            if (k == 6) {
	                k = 0;
	            }
	            sumatoria += parseInt(caracteres[j]) * parseInt(serie[k]);
	            k++;
	        }
	 
	        resto = sumatoria % 11;
	        dv = 11 - resto;
	 
	        if (dv == 10) {
	            dv = "K";
	        }
	        else if (dv == 11) {
	            dv = 0;
	        }
	 
	        if (dv.toString().trim().toUpperCase() == dig.toString().trim().toUpperCase()) return true;
	        else return false;
		}
		else return false;
    }
    else return false;
});