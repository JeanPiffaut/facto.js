<?php
class Oml_Facto_Model_Adminhtml_Customer_Renderer_Country implements Varien_Data_Form_Element_Renderer_Interface
{
   public function render(Varien_Data_Form_Element_Abstract $element)
    {
        return "sefdf";
	}
}