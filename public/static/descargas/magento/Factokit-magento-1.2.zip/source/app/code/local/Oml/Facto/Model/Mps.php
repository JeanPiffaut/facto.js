<?php
/**
 * Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@magento.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade Magento to newer
 * versions in the future. If you wish to customize Magento for your
 * needs please refer to http://www.magento.com for more information.
 *
 * @category    Mage
 * @package     Mage_Adminhtml
 * @copyright  Copyright (c) 2006-2014 X.commerce, Inc. (http://www.magento.com)
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class Oml_Facto_Model_Mps extends Mage_Core_Model_Config_Data
{
    protected function _afterLoad()
    {
		/*
		$resource = Mage::getSingleton('core/resource');
		$readConnection = $resource->getConnection('core_read');
		
		$allActivePaymentMethods = Mage::getModel('payment/config')->getActiveMethods();
		foreach($allActivePaymentMethods as $activePaymentMethod) {
			if($activePaymentMethod->isAvailable()){
				$query = "SELECT `facturacion` FROM magento_facto_mp WHERE code='".$activePaymentMethod->getCode()."'";
				$results = $readConnection->fetchAll($query);
				
				$this->setValue($results[0]['facturacion']);
				var_dump($this->getValue());
			}
		}
		/*
		
		/*
        if (!is_array($this->getValue())) {
            $value = $this->getValue();
            $this->setValue(empty($value) ? false : unserialize($value));
        }
		*/
    }

    protected function _beforeSave()
    {
		$resource = Mage::getSingleton('core/resource');
		$writeConnection = $resource->getConnection('core_write');
		$query_create = "
				CREATE TABLE IF NOT EXISTS `magento_facto_mp` (
			  `code` VARCHAR(255),
			  `facturacion` VARCHAR(255),
			  PRIMARY KEY (`code`)
			  )
		";
		$writeConnection->query($query_create);
		
		$resource = Mage::getSingleton('core/resource');
		$writeConnection = $resource->getConnection('core_write');
		$query_create = "
				CREATE TABLE IF NOT EXISTS `sales_quote_custom` (
            	`id` int(11) NOT NULL AUTO_INCREMENT,
            	`quote_id` int(11) NOT NULL,
            	`key` varchar(255) NOT NULL,
            	`value` text NOT NULL,
            	PRIMARY KEY (`id`)
              )
		";
		$writeConnection->query($query_create);
		
		$resource = Mage::getSingleton('core/resource');
		$writeConnection = $resource->getConnection('core_write');
		$query_create = "
				CREATE TABLE IF NOT EXISTS `sales_order_custom` (
            	`id` int(11) NOT NULL AUTO_INCREMENT,
            	`order_id` int(11) NOT NULL,
            	`key` varchar(255) NOT NULL,
            	`value` text NOT NULL,
            	PRIMARY KEY (`id`)
              )
		";
		$writeConnection->query($query_create);
				
		$allActivePaymentMethods = Mage::getModel('payment/config')->getActiveMethods();
		foreach($allActivePaymentMethods as $activePaymentMethod) {
			if($activePaymentMethod->isAvailable()){
				$query_insert = "INSERT INTO magento_facto_mp (code, facturacion) VALUES ('".$activePaymentMethod->getCode()."', '".$this->groups['metodospago']['fields']['lista_mp']["".$activePaymentMethod->getCode().""]['value']."')
									ON DUPLICATE KEY UPDATE facturacion='".$this->groups['metodospago']['fields']['lista_mp']["".$activePaymentMethod->getCode().""]['value']."';";
				$writeConnection->query($query_insert);
			}
		}
    }
}
