<?php
class Oml_Facto_Model_Observer{	
	public function saveQuoteBefore($evt){
        $quote = $evt->getQuote();
        $post = Mage::app()->getFrontController()->getRequest()->getPost();

        if(isset($post['billing']['facto_tipo'])){
            $var = $post['billing']['facto_tipo'];
            $quote->setFacto_tipo($var);
        }
		if(isset($post['billing']['facto_rut'])){
            $var = $post['billing']['facto_rut'];
            $quote->setFacto_rut($var);
        }
		if(isset($post['billing']['facto_razonsocial'])){
            $var = $post['billing']['facto_razonsocial'];
            $quote->setFacto_razonsocial($var);
        }
		if(isset($post['billing']['facto_giro'])){
            $var = $post['billing']['facto_giro'];
            $quote->setFacto_giro($var);
        }
    }
	
	public function saveQuoteAfter($evt){
        $quote = $evt->getQuote();
        if($quote->getFacto_tipo()){
            $var = $quote->getFacto_tipo();
            if(!empty($var)){
                $model = Mage::getModel('oml_facto/custom_quote');
                $model->deteleByQuote($quote->getId(),'facto_tipo');
                $model->setQuoteId($quote->getId());
                $model->setKey('facto_tipo');
                $model->setValue($var);
                $model->save();
            }
        }
		
		if($quote->getFacto_rut()){
            $var = $quote->getFacto_rut();
            if(!empty($var)){
                $model = Mage::getModel('oml_facto/custom_quote');
                $model->deteleByQuote($quote->getId(),'facto_rut');
                $model->setQuoteId($quote->getId());
                $model->setKey('facto_rut');
                $model->setValue($var);
                $model->save();
            }
        }
		
		if($quote->getFacto_razonsocial()){
            $var = $quote->getFacto_razonsocial();
            if(!empty($var)){
                $model = Mage::getModel('oml_facto/custom_quote');
                $model->deteleByQuote($quote->getId(),'facto_razonsocial');
                $model->setQuoteId($quote->getId());
                $model->setKey('facto_razonsocial');
                $model->setValue($var);
                $model->save();
            }
        }
		
		if($quote->getFacto_giro()){
            $var = $quote->getFacto_giro();
            if(!empty($var)){
                $model = Mage::getModel('oml_facto/custom_quote');
                $model->deteleByQuote($quote->getId(),'facto_giro');
                $model->setQuoteId($quote->getId());
                $model->setKey('facto_giro');
                $model->setValue($var);
                $model->save();
            }
        }
    }
	
	public function loadQuoteAfter($evt){
        $quote = $evt->getQuote();
        $model = Mage::getModel('oml_facto/custom_quote');
        $data = $model->getByQuote($quote->getId());
        foreach($data as $key => $value){
            $quote->setData($key,$value);
        }
    }
	
    public function saveOrderAfter($evt){
        $order = $evt->getOrder();
        $quote = $evt->getQuote();
        if($quote->getFacto_tipo()){
            $var = $quote->getFacto_tipo();
            if(!empty($var)){
                $model = Mage::getModel('oml_facto/custom_order');
                $model->deleteByOrder($order->getId(),'facto_tipo');
                $model->setOrderId($order->getId());
                $model->setKey('facto_tipo');
                $model->setValue($var);
                $order->setFacto_tipo($var);
                $model->save();
            }
        }
		
		if($quote->getFacto_rut()){
            $var = $quote->getFacto_rut();
            if(!empty($var)){
                $model = Mage::getModel('oml_facto/custom_order');
                $model->deleteByOrder($order->getId(),'facto_rut');
                $model->setOrderId($order->getId());
                $model->setKey('facto_rut');
                $model->setValue($var);
                $order->setFacto_rut($var);
                $model->save();
            }
        }
		
		if($quote->getFacto_razonsocial()){
            $var = $quote->getFacto_razonsocial();
            if(!empty($var)){
                $model = Mage::getModel('oml_facto/custom_order');
                $model->deleteByOrder($order->getId(),'facto_razonsocial');
                $model->setOrderId($order->getId());
                $model->setKey('facto_razonsocial');
                $model->setValue($var);
                $order->setFacto_Razonsocial($var);
                $model->save();
            }
        }
		
		if($quote->getFacto_giro()){
            $var = $quote->getFacto_giro();
            if(!empty($var)){
                $model = Mage::getModel('oml_facto/custom_order');
                $model->deleteByOrder($order->getId(),'facto_giro');
                $model->setOrderId($order->getId());
                $model->setKey('facto_giro');
                $model->setValue($var);
                $order->setFacto_giro($var);
                $model->save();
            }
        }
    }
	
	public function loadOrderAfter($evt){
        $order = $evt->getOrder();
        $model = Mage::getModel('oml_facto/custom_order');
        $data = $model->getByOrder($order->getId());
        foreach($data as $key => $value){
            $order->setData($key,$value);
        }
    }
}