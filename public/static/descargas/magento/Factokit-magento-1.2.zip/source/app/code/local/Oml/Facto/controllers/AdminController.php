<?php
class Oml_Facto_AdminController extends Mage_Core_Controller_Front_Action {
	public function indexAction() {
		$this->loadLayout();
        $this->renderLayout();
	}	
	
	public function facturarAction(){
		$order_id = $_POST['oml_order_id'];
		$orderObj =  Mage::getModel('sales/order')->load($order_id);
		
		$billingAddress = $orderObj->getBillingAddress()->getData();
		
		$resource = Mage::getSingleton('core/resource');
		$readConnection = $resource->getConnection('core_read');
		$query = "SELECT `key`, `value` FROM sales_order_custom WHERE order_id=".$order_id;
		$results = $readConnection->fetchAll($query);
		
		$tipo_de_documento = "";
		$rut = "";
		$razonsocial = "";
		$giro = "";
		
		foreach($results as $fila) {
			if($fila['key'] == "facto_tipo") $tipo_de_documento = $fila['value'];
			if($fila['key'] == "facto_rut") $rut = $fila['value'];
			if($fila['key'] == "facto_razonsocial") $razonsocial = $fila['value'];
			if($fila['key'] == "facto_giro") $giro = $fila['value'];
		}
		
		if($tipo_de_documento == "be") $tipo_dte = 39;
		else if($tipo_de_documento == "bee") $tipo_dte = 41;
		else if($tipo_de_documento == "fe") $tipo_dte = 33;
		else if($tipo_de_documento == "fee") $tipo_dte = 34;
		
		$fecha_emision = date('Y-m-d');
		$receptor_rut = str_replace(".", "", $rut);
		$receptor_razon = $razonsocial;
		$receptor_giro = $giro;
		
		$receptor_direccion = $billingAddress['street'];
		$receptor_comuna = $billingAddress['region'];
		$receptor_ciudad = $billingAddress['city'];
		$receptor_telefono = $billingAddress['telephone'];
		$condiciones_pago = '0';
		$receptor_email = $billingAddress['email'];
		$orden_compra_num = $order_id;
		//$orden_compra_fecha = $orderObj->getCreatedAtStoreDate();
		$orden_compra_fecha = date('Y-m-d');
		
		$descuentorecargo_global_tipo= '0';
		$descuentorecargo_global_valor= '0';
		
		$total_exento = 0;
		$total_afecto = 0;
		
		$detalles = array();
		$items = $orderObj->getAllVisibleItems();
		foreach ($items as $item) {
			$detalle = array();
			
			$detalle['cantidad'] = (int)$item->getQtyOrdered();
			$detalle['unidad'] = $item->getRealProductType();
			$detalle['glosa'] = $item->getName();
			
			$detalle['descuentorecargo_monto'] = 0;
			$detalle['descuentorecargo_porcentaje'] = 0;
		
			if($tipo_dte == 34 || $tipo_dte == 41) {
			    $detalle['monto_unitario'] = (int)$item->getPrice();
				$detalle['exento_afecto'] = 0;
				$total_exento += $detalle['cantidad'] * $detalle['monto_unitario'];
			}
			else {
			    $detalle['monto_unitario'] = round((int)$item->getPrice()/1.19,6);
				$detalle['exento_afecto'] = 1;
				$total_afecto += $detalle['cantidad'] * $detalle['monto_unitario'];
			}
			
			array_push($detalles, $detalle);
		}
		
		//GASTOS DE ENVIO
		$gastos_de_envio = (int)$orderObj->getShippingAmount();
		if($gastos_de_envio>0) {
			$detalle = array();
			
			$detalle['cantidad'] = 1;
			$detalle['unidad'] = "";
			$detalle['glosa'] = "Gastos de envío";
			$detalle['descuentorecargo_monto'] = 0;
			$detalle['descuentorecargo_porcentaje'] = 0;
		
			if($tipo_dte == 34 || $tipo_dte == 41) {
				$detalle['monto_unitario'] = $gastos_de_envio;
				$detalle['exento_afecto'] = 0;
				$total_exento += $detalle['monto_unitario'];
			} 
			else {
				$gastos_de_envio = round( ($gastos_de_envio / 1.19), 6);
				$detalle['monto_unitario'] = $gastos_de_envio;
				$detalle['exento_afecto'] = 1;
				$total_afecto += $detalle['monto_unitario'];
			}
			
			array_push($detalles, $detalle);
		}
		
		$total_iva = round($total_afecto * 0.19);
		$total_exento = round($total_exento);
		$total_afecto = round($total_afecto);
		$total_final = $total_iva + $total_afecto + $total_exento;
		
		require_once(Mage::getModuleDir('etc', 'Oml_Facto')."/nusoap/nusoap.php");
		
		try {
			$client = new nusoap_client(Mage::getStoreConfig('facto_options/webservice/webservice_url'));
			$client->setCredentials(Mage::getStoreConfig('facto_options/webservice/webservice_user'), Mage::getStoreConfig('facto_options/webservice/webservice_pass'), "basic");

			$cadena_xml = "
					<documento xsi:type='urn:emitir_dte'>
						<encabezado xsi:type='urn:encabezado'>
							<tipo_dte xsi:type='xsd:string'>".$tipo_dte."</tipo_dte>
							<fecha_emision xsi:type='xsd:date'>".$fecha_emision."</fecha_emision>
							<receptor_rut xsi:type='xsd:string'>".$receptor_rut."</receptor_rut>
							<receptor_razon xsi:type='xsd:string'>".htmlspecialchars($receptor_razon)."</receptor_razon>
							<receptor_direccion xsi:type='xsd:string'>".htmlspecialchars($receptor_direccion)."</receptor_direccion>
							<receptor_comuna xsi:type='xsd:string'>".htmlspecialchars($receptor_comuna)."</receptor_comuna>
							<receptor_ciudad xsi:type='xsd:string'>".htmlspecialchars($receptor_ciudad)."</receptor_ciudad>

							<receptor_telefono xsi:type='xsd:string'>".htmlspecialchars($receptor_telefono)."</receptor_telefono>
							<receptor_giro xsi:type='xsd:string'>".htmlspecialchars($receptor_giro)."</receptor_giro>
							<condiciones_pago xsi:type='xsd:string'>".htmlspecialchars($condiciones_pago)."</condiciones_pago>
							<receptor_email xsi:type='xsd:string'>".htmlspecialchars($receptor_email)."</receptor_email>
							<orden_compra_num xsi:type='xsd:string'>".$orden_compra_num."</orden_compra_num>
							<orden_compra_fecha xsi:type='xsd:date'>".$orden_compra_fecha."</orden_compra_fecha>
						</encabezado>
									
						<detalles xsi:type='urn:detalles'>"; 
			foreach ($detalles as $key => $detalle){
				$cadena_xml .= "
							<detalle xsi:type='urn:detalle'>
								<cantidad xsi:type='xsd:int'>".$detalle['cantidad']."</cantidad>
								<unidad xsi:type='xsd:string'>".$detalle['unidad']."</unidad>
								<glosa xsi:type='xsd:string'>".htmlspecialchars($detalle['glosa'])."</glosa>
								<monto_unitario xsi:type='xsd:decimal'>".$detalle['monto_unitario']."</monto_unitario>
								<exento_afecto xsi:type='xsd:boolean'>".$detalle['exento_afecto']."</exento_afecto>
							</detalle>";
			}
			
			$cadena_xml .= "
						</detalles>
					
						<totales xsi:type='urn:totales'>	
							<total_exento xsi:type='xsd:int'>".$total_exento."</total_exento>
							<total_afecto xsi:type='xsd:int'>".$total_afecto."</total_afecto>
							<total_iva xsi:type='xsd:int'>".$total_iva."</total_iva>
							<total_final xsi:type='xsd:int'>".$total_final."</total_final>
						</totales>
					</documento>";			
			
			$client->soap_defencoding = 'UTF-8';
			$client->decode_utf8 = false;
			$response = $client->call("emitirDocumento", $cadena_xml);
			$err = $client->getError();
			
			//********* LOG ***************
			$writeConnection = $resource->getConnection('core_write');
			$query_create = "
					CREATE TABLE IF NOT EXISTS `magento_facto_log` (
				  `id_envio` int(11) NOT NULL AUTO_INCREMENT,
				  `fecha` date,
				  `request` text,
				  `response` text,
				  `estado_envio` int(11),
				  PRIMARY KEY (`id_envio`)
				  )
			";
			$writeConnection->query($query_create);
			
			$myText = print_r($response,true);
			$myText = Mage::getSingleton('core/resource')->getConnection('default_write')->quote($myText);
			$requestdelcliente = Mage::getSingleton('core/resource')->getConnection('default_write')->quote($client->request);
			$query_insert = "INSERT INTO magento_facto_log (fecha, request, response, estado_envio) VALUES('".$fecha_emision."', ".$requestdelcliente.", ".$myText.", '".$response["resultado"]["status"]."')";
			$writeConnection->query($query_insert);
		
			//********* LOG ***************
		
			$status = $response['resultado']['status'];
			$msg = '';
			$enlace = '';
			
			if($err) {
				$status = 1;
				$msg = $err;
			}
			else if($status==0) {
				$msg = $response['resultado']['mensaje_error'];
				$enlace = $response['enlaces']['dte_pdf'];
			}
			else if($status==1) {
				$msg = $response['resultado']['mensaje_error'];
			}
			else if($status==2) {
				$msg = $response['resultado']['mensaje_error'];
				$enlace = $response['enlaces']['dte_pdf'];
			}
			
			// Veamos si existe el registro, si no, lo creamos
			$query = "SELECT status, msg, enlace FROM magento_facto_order_mp WHERE order_id='".$order_id."'";
			$results = $readConnection->fetchAll($query);
			
			if (count($results) != 0)
			{
			
    			$query_insert = "UPDATE magento_facto_order_mp SET status='".$status."', msg='".$msg."', enlace='".$enlace."' WHERE order_id='".$order_id."'";
    			$writeConnection->query($query_insert);
			
			}
			else
			{
			    $query_insert = "INSERT INTO magento_facto_order_mp (status,msg,enlace,order_id) VALUES ('".$status."','".$msg."','".$enlace."','".$order_id."')";
			    $writeConnection->query($query_insert);
			}
				
			$respuesta = array('status'=>$status, 'msg'=>$msg, 'enlace'=>$enlace );
			print json_encode($respuesta, JSON_FORCE_OBJECT);
		}
		catch (Exception $e)
		{
			//var_dump($e);
		}
	}
}