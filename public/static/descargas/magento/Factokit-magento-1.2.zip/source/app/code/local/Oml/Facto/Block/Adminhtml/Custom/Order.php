<?php
class Oml_Facto_Block_Adminhtml_Custom_Order extends Mage_Adminhtml_Block_Sales_Order_Abstract{
	public function getCustomVars(){
		$model = Mage::getModel('oml_facto/custom_order');
		return $model->getByOrder($this->getOrder()->getId());
	}
}