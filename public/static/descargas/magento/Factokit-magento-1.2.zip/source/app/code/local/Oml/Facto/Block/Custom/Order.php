<?php
class Oml_Facto_Block_Custom_Order extends Mage_Core_Block_Template{
	public function getCustomVars(){
		$model = Mage::getModel('oml_facto/custom_order');
		return $model->getByOrder($this->getOrder()->getId());
	}

	public function getOrder()
	{
		return Mage::registry('current_order');
	}
}