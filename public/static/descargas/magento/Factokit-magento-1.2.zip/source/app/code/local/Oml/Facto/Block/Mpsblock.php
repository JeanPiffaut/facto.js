<?php
class Oml_Facto_Block_Mpsblock extends Mage_Adminhtml_Block_System_Config_Form_Field {
    protected function _getElementHtml(Varien_Data_Form_Element_Abstract $element)
    {
		$allActivePaymentMethods = Mage::getModel('payment/config')->getActiveMethods();
		
		$resource = Mage::getSingleton('core/resource');
		$readConnection = $resource->getConnection('core_read');
		
		$resource = Mage::getSingleton('core/resource');
		$writeConnection = $resource->getConnection('core_write');
		$query_create = "
				CREATE TABLE IF NOT EXISTS `magento_facto_mp` (
			  `code` VARCHAR(255),
			  `facturacion` VARCHAR(255),
			  PRIMARY KEY (`code`)
			  )
		";
		$writeConnection->query($query_create);
		
		$resource = Mage::getSingleton('core/resource');
		$writeConnection = $resource->getConnection('core_write');
		$query_create = "
				CREATE TABLE IF NOT EXISTS `sales_quote_custom` (
            	`id` int(11) NOT NULL AUTO_INCREMENT,
            	`quote_id` int(11) NOT NULL,
            	`key` varchar(255) NOT NULL,
            	`value` text NOT NULL,
            	PRIMARY KEY (`id`)
              )
		";
		$writeConnection->query($query_create);
		
		$resource = Mage::getSingleton('core/resource');
		$writeConnection = $resource->getConnection('core_write');
		$query_create = "
				CREATE TABLE IF NOT EXISTS `sales_order_custom` (
            	`id` int(11) NOT NULL AUTO_INCREMENT,
            	`order_id` int(11) NOT NULL,
            	`key` varchar(255) NOT NULL,
            	`value` text NOT NULL,
            	PRIMARY KEY (`id`)
              )
		";
		$writeConnection->query($query_create);
		
		$html = "<table>";
		foreach($allActivePaymentMethods as $activePaymentMethod) {
			if($activePaymentMethod->isAvailable()){
				//var_dump($activePaymentMethod);
				$html .= "<tr>";
			
				$html .= "<td>";
				$paymentTitle = Mage::getStoreConfig('payment/'.$activePaymentMethod->getCode().'/title');
				$html .= $paymentTitle;
				$html .= "</td>";
				
				$query = "SELECT `facturacion` FROM magento_facto_mp WHERE code='".$activePaymentMethod->getCode()."'";
				$results = $readConnection->fetchAll($query);
				$facturacion = $results[0]['facturacion'];
				
				$html .= "<td>";
				$html .= "<select style='width:140px;' name='groups[metodospago][fields][lista_mp][".$activePaymentMethod->getCode()."][value]' class='select'>";
				
				$html .= "<option value='manual' ";
				if($facturacion=='manual') $html .= 'selected';
				$html .= ">Manual</option>";
				
				$html .= "<option value='auto' ";
				if($facturacion=='auto') $html .= 'selected';
				$html .= ">Autom&aacute;tica</option>";
				
				$html .= "</select>";
				$html .= "</td>";
			
				$html .= "</tr>";
			}
		}

		$html .= "</table>";

        return $html;
    }
}
?>