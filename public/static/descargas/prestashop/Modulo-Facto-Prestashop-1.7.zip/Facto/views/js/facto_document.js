function camposaddress(){
    $('input[name=facto_tipo_documento]').parent().parent().children('label').html('Tipo de documento');
    $('input[name=facto_tipo_documento]').replaceWith('<select class=\"form-control form-control-select\" name=\"facto_tipo_documento\" id=\"facto_tipo_documento\" onchange=\"facto_cambiar()\" required=\"\"><option value=\"0\" disabled selected>-- por favor, seleccione --</option></select>');
    facto_cambiar();
}
            
if (document.addEventListener){ window.addEventListener('load',camposaddress,false);}
else{ window.attachEvent('onload',camposaddress);}