$(document).ready(function() {
		jQuery('input[name=vat_number]').Rut({
		on_error: function(){
			if(jQuery('input[name=vat_number]').parent().parent().is('visible')){
				alert('El rut ingresado es incorrecto');jQuery('input[name=vat_number]').val('');jQuery('input[name=vat_number]').focus();
			}else{
				jQuery('input[name=vat_number]').val('00.000.000-0');
			}
		},
       format_on: 'keyup' 
	});
});


function facto_cambiar(){
	if($("#facto_tipo_documento").val() == 33 || $("#facto_tipo_documento").val() == 34) {
		$(".form-group input[name=company]").parent().parent().show();
		$(".form-group input[name=vat_number]").parent().parent().show();
		$(".form-group input[name=other]").parent().parent().show();
	}else{		
		$(".form-group input[name=company]").parent().parent().hide();
		$(".form-group input[name=vat_number]").parent().parent().hide();
		$(".form-group input[name=vat_number]").val('');
		$(".form-group input[name=other]").parent().parent().hide();
	}
}