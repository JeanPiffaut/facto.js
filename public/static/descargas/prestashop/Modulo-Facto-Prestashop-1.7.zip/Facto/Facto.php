<?php
/**
 * 2007-2019 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 *  @author    PrestaShop SA <contact@prestashop.com>
 *  @copyright 2007-2019 PrestaShop SA
 *  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of PrestaShop SA
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class Facto extends Module
{
    protected $config_form = false;
    public $rut_vendedor;
    public $ws_user;
    public $ws_pass;
    public $ws_url;
    
    public function __construct()
    {
        $this->name = 'Facto';
        $this->tab = 'administration';
        $this->version = '2.1.5';
        $this->author = 'OML';
        $this->need_instance = 0;
        
        /**
         * Set $this->bootstrap to true if your module is compliant with bootstrap (PrestaShop 1.6)
         */
        $this->bootstrap = true;
        
        $this->displayName = $this->l('Facto OML');
        $this->description = $this->l('Facto integration.');
        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
        
        $config_error = null;
        $config_error_doc = null;
        
        $config = Configuration::getMultiple(array('FACTO_RUT_VENDEDOR', 'FACTO_WS_USER', 'FACTO_WS_PASS', 'FACTO_WS_URL'));
        
        // Si hay algun campo avcio, se considerara desconfigurado.
        foreach($config as $key){
            if($key == ""){
                $config_error = true;
            }
        }

        $config_doc = Configuration::getMultiple(array('FACTO_FACTURA_ELECTRONICA', 'FACTO_FACTURA_EXENTA_ELECTRONICA', 'FACTO_BOLETA_ELECTRONICA', 'FACTO_BOLETA_EXENTA_ELECTRONICA'));
        
        // Si hay almenos un campo seleccionado, se considerara configurado
        foreach($config_doc as $key){
            if($key != ""){
                $config_error_doc = true;
            }
        }
        
        if($config_error == true){
            $this->warning = $this->l('The data must be configured for the connection to the API.');
        }elseif($config_error_doc != true){
            $this->warning = $this->l('You must select at least one type of document.');
        }
        
        parent::__construct();
    }
    
    /**
     * Don't forget to create update methods if needed:
     * http://doc.prestashop.com/display/PS16/Enabling+the+Auto-Update
     */
    public function install()
    {
        Configuration::updateValue('FACTO_FACTURA_ELECTRONICA', false);
        Configuration::updateValue('FACTO_FACTURA_EXENTA_ELECTRONICA', false);
        Configuration::updateValue('FACTO_BOLETA_ELECTRONICA', false);
        Configuration::updateValue('FACTO_BOLETA_EXENTA_ELECTRONICA', false);
        Configuration::updateValue('FACTO_RUT_VENDEDOR', false);
        Configuration::updateValue('FACTO_WS_USER', false);
        Configuration::updateValue('FACTO_WS_PASS', false);
        Configuration::updateValue('FACTO_WS_URL', false);
        
        include(dirname(__FILE__).'/sql/install.php');
        
        return parent::install()
        && $this->registerHook('displayHeader')
        && $this->registerHook('actionPaymentConfirmation')
        && $this->registerHook('actionValidateCustomerAddressForm')
        && $this->registerHook('displayOrderConfirmation')
        && $this->registerHook('displayAdminOrderLeft');
    }
    
    public function uninstall()
    {
        Configuration::deleteByName('FACTO_FACTURA_ELECTRONICA');
        Configuration::deleteByName('FACTO_FACTURA_EXENTA_ELECTRONICA');
        Configuration::deleteByName('FACTO_BOLETA_ELECTRONICA');
        Configuration::deleteByName('FACTO_BOLETA_EXENTA_ELECTRONICA');
        Configuration::deleteByName('FACTO_RUT_VENDEDOR');
        Configuration::deleteByName('FACTO_WS_USER');
        Configuration::deleteByName('FACTO_WS_PASS');
        Configuration::deleteByName('FACTO_WS_URL');
        
        include(dirname(__FILE__).'/sql/uninstall.php');
        
        return parent::uninstall();
    }
    
    /**
     * Load the configuration form
     */
    public function getContent(){
        $output = null;
        
        $this->context->smarty->assign('module_dir', $this->_path);
        
        if (((bool)Tools::isSubmit('submitTipoDocumento')) == true) {
            if($this->postProcessDoc() == 1){
                $output = $this->displayConfirmation($this->l('Document types successfully updated.'));
            }
        }
        if (((bool)Tools::isSubmit('submitDatosConexion')) == true) {
            if($this->postProcessCon() == 1){
                $output = $this->displayConfirmation($this->l('Connection Data updated Successfully.'));
                
                require_once(_PS_MODULE_DIR_.'Facto/lib/nusoap/nusoap.php');
                
                $url = Configuration::get('FACTO_WS_URL');
                $user = Configuration::get('FACTO_WS_USER');
                $pass = Configuration::get('FACTO_WS_PASS');
                 
                $connection = new nusoap_client($url);
                $connection->setCredentials($user, $pass, "basic");
                
                $cadena_xml = null;
                
                $cadena_xml = "
                    <documento xsi:type='urn:emitir_dte'>
    					<encabezado xsi:type='urn:encabezado'>
    						<tipo_dte xsi:type='xsd:string'>?</tipo_dte>
    					</encabezado>
                    </documento>
                ";
                
                // Realizamos una consulta  la API de Facto
                $response = $connection->call("emitirDocumento", $cadena_xml);
                $err = $connection->getError();
                
                // Si retorna algo, es por que se realizo la conexion
                if($err){
                    if(strpos($err, '403') == true){ $output .= $this->displayError($this->l('Error 403: Incorrect Rut, User or Pass.'));}
                    elseif(strpos($err, '404') == true){ $output .= $this->displayError($this->l('Error 404: URL not found')); }
                    else{ $output .= $this->displayError($this->l('Error: '.$err.$response['resultado']['status'])); }
                }else{
                    $output .= $this->displayConfirmation($this->l('The connection to the FACTO API was successful.'));
                    $this->facto_config = true;
                }
            }else{
                $output = $this->displayError($this->l('There can not be empty fields.'));
            }
        }
        if(!$output){ $output = $this->context->smarty->fetch($this->local_path.'views/templates/admin/configure.tpl'); }
        else{ $output .= $this->context->smarty->fetch($this->local_path.'views/templates/admin/configure.tpl'); }
        
        return $output.$this->renderFormDoc().$this->renderFormCon();
    }
    
    /**
     * Create the form that will be displayed in the configuration of your module.
     * Inicio Informacion Panel de Documentos
     */
    protected function renderFormDoc()
    {
        $fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->l('Type Documents'),
                    'icon' => 'icon-file-text',
                ),
                'input' => array(
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Factura Electrónica'),
                        'name' => 'FACTO_FACTURA_ELECTRONICA',
                        'is_bool' => true,
                        'values' => array(
                            array(
                                'id' => 'active_on',
                                'value' => true,
                                'label' => $this->l('Enabled'),
                            ),
                            array(
                                'id' => 'active_off',
                                'value' => false,
                                'label' => $this->l('Disabled'),
                            )
                        )
                    ),
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Factura Exenta Electrónica'),
                        'name' => 'FACTO_FACTURA_EXENTA_ELECTRONICA',
                        'is_bool' => true,
                        'values' => array(
                            array(
                                'id' => 'active_on',
                                'value' => true,
                                'label' => $this->l('Enabled'),
                            ),
                            array(
                                'id' => 'active_off',
                                'value' => false,
                                'label' => $this->l('Disabled'),
                            )
                        )
                    ),
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Boleta Electrónica'),
                        'name' => 'FACTO_BOLETA_ELECTRONICA',
                        'is_bool' => true,
                        'values' => array(
                            array(
                                'id' => 'active_on',
                                'value' => true,
                                'label' => $this->l('Enabled'),
                            ),
                            array(
                                'id' => 'active_off',
                                'value' => false,
                                'label' => $this->l('Disabled'),
                            )
                        )
                    ),
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Boleta Exenta Electrónica'),
                        'name' => 'FACTO_BOLETA_EXENTA_ELECTRONICA',
                        'is_bool' => true,
                        'values' => array(
                            array(
                                'id' => 'active_on',
                                'value' => true,
                                'label' => $this->l('Enabled'),
                            ),
                            array(
                                'id' => 'active_off',
                                'value' => false,
                                'label' => $this->l('Disabled'),
                            )
                        )
                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                    'name' => 'submitTipoDocumento'
                ),
            )
        );
        
        $helper = new HelperForm();
        $lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
        
        $helper->module = $this;
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->default_form_language = $lang->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
        
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitFactoModule';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
        .'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        
        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFormValuesDoc(), /* Add values for your inputs */
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        );
        
        return $helper->generateForm(array($fields_form));
    }
    
    protected function getConfigFormValuesDoc()
    {
        return array(
            'FACTO_FACTURA_ELECTRONICA' => Configuration::get('FACTO_FACTURA_ELECTRONICA', false),
            'FACTO_FACTURA_EXENTA_ELECTRONICA' => Configuration::get('FACTO_FACTURA_EXENTA_ELECTRONICA', false),
            'FACTO_BOLETA_ELECTRONICA' => Configuration::get('FACTO_BOLETA_ELECTRONICA', false),
            'FACTO_BOLETA_EXENTA_ELECTRONICA' => Configuration::get('FACTO_BOLETA_EXENTA_ELECTRONICA', false),
        );
    }
    
    protected function postProcessDoc()
    {
        $form_values = $this->getConfigFormValuesDoc();
        
        foreach (array_keys($form_values) as $key) {
            Configuration::updateValue($key, Tools::getValue($key));
        }
        return true;
    }
    
    /*
     * Fin Panel de documentos
     * Create the form that will be displayed in the configuration of your module.
     * Inicio Panel de Conexion
     * */
    protected function renderFormCon()
    {
        $fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->l('Connection data with FACTO'),
                    'icon' => 'icon-link',
                ),
                'input' => array(
                    array(
                        'col' => 4,
                        'type' => 'text',
                        'name' => 'FACTO_WS_USER',
                        'label' => $this->l('Webservice User'),
                        'desc' => $this->l('Please enter the user requested by FACTO.'),
                        'required' => true
                    ),
                    array(
                        'col' => 4,
                        'type' => 'password',
                        'name' => 'FACTO_WS_PASS',
                        'label' => $this->l('Webservice Pass'),
                        'desc' => $this->l('Please enter the password requested by FACTO.'),
                        'required' => true
                    ),
                    array(
                        'col' => 4,
                        'type' => 'text',
                        'name' => 'FACTO_WS_URL',
                        'label' => $this->l('Webservice URL'),
                        'desc' => $this->l('Please enter the URL used by the FACTO Webservice.'),
                        'required' => true
                    )
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                    'name' => 'submitDatosConexion'
                ),
            )
        );
        
        $helper = new HelperForm();
        $lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
        
        $helper->module = $this;
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->default_form_language = $lang->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
        
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitFactoModule';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
        .'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        
        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFormValuesCon(), /* Add values for your inputs */
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        );
        
        return $helper->generateForm(array($fields_form));
    }
    
    protected function getConfigFormValuesCon(){
        return array(
            'FACTO_WS_USER' => Configuration::get('FACTO_WS_USER', false),
            'FACTO_WS_PASS' => Configuration::get('FACTO_WS_PASS', false),
            'FACTO_WS_URL' => Configuration::get('FACTO_WS_URL', false),
        );
    }
    
    protected function postProcessCon(){
        $form_values = $this->getConfigFormValuesCon();
        
        foreach (array_keys($form_values) as $key) {
            if(Tools::getValue($key) == ""){
                $error = true;
            }
        }
        
        if(!isset($error)){
            foreach (array_keys($form_values) as $key) {
                Configuration::updateValue($key, Tools::getValue($key));
            }
            return true;
        }else{
            return false;
        }
    }
    
    /**
     * Hooks
     **/
    public function hookDisplayHeader($params) {
        $this->context->controller->addJS(($this->_path).'views/js/facto_jquery_Rut.js');
        $this->context->controller->addJS(($this->_path).'views/js/facto_order_address.js');
        
            // Agregamos los campos extra al formulario, tipo de documento al comienzo
            $salida = "<script type=\"text/javascript\">
    function camposaddress(){
        $('input[name=facto_tipo_documento]').parent().parent().children('label').html('Tipo de documento');
        $('input[name=facto_tipo_documento]').replaceWith('<select class=\"form-control form-control-select\" name=\"facto_tipo_documento\" id=\"facto_tipo_documento\" onchange=\"facto_cambiar()\" required=\"\"><option value=\"0\" disabled selected>-- por favor, seleccione --</option>";
            if (Configuration::get('FACTO_FACTURA_ELECTRONICA') == true) $salida .= "<option value=\"33\">Factura Electrónica</option>";
            if (Configuration::get('FACTO_FACTURA_EXENTA_ELECTRONICA') == true) $salida .= "<option value=\"34\">Factura Electrónica Exenta</option>";
            if (Configuration::get('FACTO_BOLETA_ELECTRONICA') == true) $salida .= "<option value=\"39\">Boleta Electrónica</option>";
            if (Configuration::get('FACTO_BOLETA_EXENTA_ELECTRONICA') == true) $salida .= "<option value=\"41\">Boleta Electrónica Exenta</option>";
            $salida .= "</select>');
        facto_cambiar();
    }
        if (document.addEventListener){ window.addEventListener('load',camposaddress,false);}
        else{ window.attachEvent('onload',camposaddress);}
</script>";
        
        return $salida;
    }
    
    public function hookDisplayAdminOrderLeft($params){
        $cart_id = Cart::getCartIdByOrderId($params['id_order']);
        $cart = new Cart($cart_id);
        
        $address = new Address(intval($cart->id_address_invoice));
        
        $state = new State($address->id_state);
        
        $factoValues = $this->getFactoValues($cart->id);
        
        $sql_facto_log = '  SELECT order_id, cart_id, enlace_pdf, request, response 
                            FROM '._DB_PREFIX_.'facto_log
                            WHERE order_id = "'.$params['id_order'].'";';
        $query_facto_log = Db::getInstance()->getRow($sql_facto_log);
        
        if($factoValues['tipo'] == 33) $this->context->smarty->assign('facto_tipo_documento',"Factura electrónica");
        if($factoValues['tipo'] == 34) $this->context->smarty->assign('facto_tipo_documento',"Factura exenta electrónica");
        if($factoValues['tipo'] == 39) $this->context->smarty->assign('facto_tipo_documento',"Boleta electrónica");
        if($factoValues['tipo'] == 41) $this->context->smarty->assign('facto_tipo_documento',"Boleta exenta electrónica");

        $this->context->smarty->assign('facto_razon_social',$address->company);
        $this->context->smarty->assign('facto_rut',$address->vat_number);
        $this->context->smarty->assign('facto_direccion',$address->address1);
        $this->context->smarty->assign('facto_ciudad',$address->city);
        $this->context->smarty->assign('facto_comuna',$state->name);
        $this->context->smarty->assign('facto_giro',$factoValues['giro']);
        $this->context->smarty->assign('facto_fono',$address->phone);
        $this->context->smarty->assign('facto_request',$query_facto_log['request']);
        $this->context->smarty->assign('facto_response',$query_facto_log['response']);
        $this->context->smarty->assign('facto_enlace_pdf',$query_facto_log['enlace_pdf']);
        
        return $this->display(__FILE__, 'views/templates/admin/order-facto.tpl');
    }
    
    public function hookActionPaymentConfirmation($params){
        $rut = "";
        $razonsocial = "";
        $giro = "";
        
        $cart_id = Cart::getCartIdByOrderId($params['id_order']);
        
        $cart = new Cart($cart_id);
        $address = new Address(intval($cart->id_address_invoice));
        $order = new Order($params['id_order']);
        $customer = new Customer($order->id_customer);
        
        $sql_facto_log = '  SELECT order_id, cart_id, enlace_pdf
                            FROM '._DB_PREFIX_.'facto_log
                            WHERE   order_id = "'.$params['id_order'].'" AND
                                    estado_envio IN (0,2); ';
        $query_facto_log = Db::getInstance()->getRow($sql_facto_log);
        if($query_facto_log != false){
            return true;
        }else{
            $factoValues = $this->getFactoValues($cart->id);
            
            if(empty($factoValues['tipo']))
            {
                $sql_isset_dato = ' SELECT tipo, rut, razon_social, giro
                                    FROM '._DB_PREFIX_.'facto fa
                                        INNER JOIN '._DB_PREFIX_.'cart ca ON(fa.cart_id = ca.id_cart)
                                        INNER JOIN '._DB_PREFIX_.'customer cu ON(cu.id_customer = ca.id_customer)
                                    WHERE ca.id_cart = "'.$cart->id.'"
                                    ORDER BY ca.id_cart; ';
                $query_isset_dato = Db::getInstance()->getRow($sql_isset_dato);
                
                if($query_isset_dato != false)
                {
                    $this->setFactoValues($cart->id, $query_isset_dato['tipo'], "", "", $query_isset_dato['giro']);
                    $factoValues = $this->getFactoValues($cart->id);
                }
            }
            
            if($factoValues['tipo'] == 33 || $factoValues['tipo'] == 34){
                $rut = $address->vat_number;
                $razonsocial = $address->company;
                $giro = $factoValues['giro'];
            }
            
            $fecha_emision = date('Y-m-d');
            $receptor_rut = str_replace(".", "", $rut);
            $receptor_razon = $razonsocial;
            $receptor_giro = $giro;
            $receptor_direccion = $address->address1;
            
            if($address->id_state != 0)
            {
                $receptor_comuna = State::getNameById($address->id_state);
            }
            else
            {
                $receptor_comuna = $address->city;
            }
            
            $receptor_ciudad = $address->city;
            $receptor_telefono = $address->phone;
            $receptor_email = $customer->email;
            
            $condiciones_pago = '0';
            $orden_compra_num = $params['id_order'];
            $orden_compra_fecha = date('Y-m-d');
            $descuentorecargo_global_tipo= '0';
            $descuentorecargo_global_valor= '0';
            
            $total_exento = 0;
            $total_afecto = 0;
            
            $detalles = array();
            $items = $order->getCartProducts();
            
            foreach($items as $item){
                $detalle = array();
                
                $detalle['cantidad'] = (int)$item['product_quantity'];
                $detalle['unidad'] = "";
                $detalle['glosa'] =  ($item['product_name']);
                $detalle['descuentorecargo_monto'] = 0;
                $detalle['descuentorecargo_porcentaje'] = 0;
                
                if($factoValues['tipo'] == 34 || $factoValues['tipo'] == 41 )
                {
                    $detalle['monto_unitario'] = round($item['unit_price_tax_incl'], 6);
                    $detalle['exento_afecto'] = 0;
                    $total_exento += round($detalle['cantidad'] * $detalle['monto_unitario']);
                }
                else
                {
                    $detalle['monto_unitario'] = round(($item['unit_price_tax_incl'] / 1.19), 6) ;
                    $detalle['exento_afecto'] = 1;
                    $total_afecto += round($detalle['cantidad'] * $detalle['monto_unitario']);
                }
                array_push($detalles, $detalle);
            }
            
            $gastos_de_envio = (int)$order->total_shipping;
            
            if($gastos_de_envio > 0)
            {
                $detalle = array();
                
                $detalle['cantidad'] = 1;
                $detalle['unidad'] = "";
                $detalle['glosa'] = "Gastos de envío";
                $detalle['descuentorecargo_monto'] = 0;
                $detalle['descuentorecargo_porcentaje'] = 0;
                
                if($factoValues['tipo'] == 34 || $factoValues['tipo']== 41) 
                {
                    $detalle['monto_unitario'] = $gastos_de_envio;
                    $detalle['exento_afecto'] = 0;
                    $total_exento += $detalle['monto_unitario'];
                }
                else
                {
                    $gastos_de_envio = round( ($gastos_de_envio / 1.19), 6);
                    $detalle['monto_unitario'] = $gastos_de_envio;
                    $detalle['exento_afecto'] = 1;
                    $total_afecto += round($detalle['monto_unitario']);
                }
                array_push($detalles, $detalle);
            }
            
            $rules = $order->getCartRules();
            $totalpedido = $order->total_paid;
            $descuentoafecto = 0;
            $descuentoexento = 0;
            
            if($factoValues['tipo'] == 34 || $factoValues['tipo'] == 41)
            {
                $descuentoexento = round($order->total_paid) - round($total_exento);
            }
            else
            {
                $descuentoafecto = round((round($order->total_paid) - round($total_afecto) - round($total_afecto*0.19)) / 1.19);
            }
            
            $total_afecto = round($total_afecto)+$descuentoafecto;
            $total_exento = round($total_exento)+$descuentoexento;
            $total_iva = round(($total_afecto) * 0.19);
            
            $total_final = $total_iva + $total_afecto + $total_exento;
            
            require_once(_PS_MODULE_DIR_.'Facto/lib/nusoap/nusoap.php');
            
            try{
                $url = Configuration::get('FACTO_WS_URL');
                $user = Configuration::get('FACTO_WS_USER');
                $pass = Configuration::get('FACTO_WS_PASS');
                
                $connection = new nusoap_client($url);
                $connection->setCredentials($user, $pass, "basic");
                
                $cadena_xml = "
				<documento xsi:type='urn:emitir_dte'>
					<encabezado xsi:type='urn:encabezado'>
						<tipo_dte xsi:type='xsd:string'>".$factoValues['tipo']."</tipo_dte>
						<fecha_emision xsi:type='xsd:date'>".$fecha_emision."</fecha_emision>";
                
                if($factoValues['tipo'] == 33 || $factoValues['tipo'] == 34)
                {
				    $cadena_xml .= "<receptor_rut xsi:type='xsd:string'>".$receptor_rut."</receptor_rut>";
				}
				
				$cadena_xml .= "
                        <receptor_razon xsi:type='xsd:string'><![CDATA[".$this->setEncodingXml($receptor_razon)."]]></receptor_razon>
						<receptor_direccion xsi:type='xsd:string'><![CDATA[".$this->setEncodingXml($receptor_direccion)."]]></receptor_direccion>
						<receptor_comuna xsi:type='xsd:string'><![CDATA[".$this->setEncodingXml($receptor_comuna)."]]></receptor_comuna>
						<receptor_ciudad xsi:type='xsd:string'><![CDATA[".$this->setEncodingXml($receptor_ciudad)."]]></receptor_ciudad>
						    
						<receptor_telefono xsi:type='xsd:string'><![CDATA[".$this->setEncodingXml($receptor_telefono)."]]></receptor_telefono>
						<receptor_giro xsi:type='xsd:string'><![CDATA[".$this->setEncodingXml($receptor_giro)."]]></receptor_giro>
						<condiciones_pago xsi:type='xsd:string'><![CDATA[".$this->setEncodingXml($condiciones_pago)."]]></condiciones_pago>
						<receptor_email xsi:type='xsd:string'><![CDATA[".$this->setEncodingXml($receptor_email)."]]></receptor_email>
						<orden_compra_num xsi:type='xsd:string'>".$orden_compra_num."</orden_compra_num>
						<orden_compra_fecha xsi:type='xsd:date'>".$orden_compra_fecha."</orden_compra_fecha>
					</encabezado>
						    
				    <detalles xsi:type='urn:detalles'>";
                foreach($detalles as $key => $detalle){
                    $cadena_xml .= "
						<detalle xsi:type='urn:detalle'>
							<cantidad xsi:type='xsd:int'>".$detalle['cantidad']."</cantidad>
							<unidad xsi:type='xsd:string'>".$detalle['unidad']."</unidad>
							<glosa xsi:type='xsd:string'><![CDATA[".$this->setEncodingXml($detalle['glosa'])."]]></glosa>
							<monto_unitario xsi:type='xsd:decimal'>".$detalle['monto_unitario']."</monto_unitario>
							<exento_afecto xsi:type='xsd:boolean'>".$detalle['exento_afecto']."</exento_afecto>
						</detalle>";
                }
                $cadena_xml .= "
				    </detalles>";
                
                if($descuentoafecto!= 0){
                    $cadena_xml .= "
                    <descuentorecargoglobales xsi:type='urn:descuentorecargoglobales'>
                        <descuentorecargoglobal xsi:type='urn:descuentorecargoglobal'>
                            <descrec xsi:type='xsd:string'>";
                    if($descuentoexento < 0) $cadena_xml .= "DA";
                    else $cadena_xml .= "RA";
                    $cadena_xml .= "
                            </descrec>
                            <valor xsi:type='xsd:decimal'>".abs($descuentoafecto)."</valor>
                            <tipovalor xsi:type='xsd:string'>$</tipovalor>
                            <glosa xsi:type='xsd:string'>Descuento/Recargo</glosa>
                        </descuentorecargoglobal>
                    </descuentorecargoglobales>";
                }
                
                if ($descuentoexento != 0){
                    $cadena_xml .= "
                    <descuentorecargoglobales xsi:type='urn:descuentorecargoglobales'>
                        <descuentorecargoglobal xsi:type='urn:descuentorecargoglobal'>
                            <descrec xsi:type='xsd:string'>";
                    
                    if ($descuentoafecto < 0) $cadena_xml .= "DE";
                    else $cadena_xml .= "RE";
                    
                    $cadena_xml .= "
                            </descrec>
                            <valor xsi:type='xsd:decimal'>".abs($descuentoexento)."</valor>
                            <tipovalor xsi:type='xsd:string'>$</tipovalor>
                            <glosa xsi:type='xsd:string'>Descuento/Recargo</glosa>
                        </descuentorecargoglobal>
                    </descuentorecargoglobales>";
                }
                
                $cadena_xml .= "
                    <totales xsi:type='urn:totales'>
    					<total_exento xsi:type='xsd:int'>".$total_exento."</total_exento>
    					<total_afecto xsi:type='xsd:int'>".$total_afecto."</total_afecto>
    					<total_iva xsi:type='xsd:int'>".$total_iva."</total_iva>
    					<total_final xsi:type='xsd:int'>".$total_final."</total_final>
    				</totales>
    			</documento>";
                
                $response = $connection->call("emitirDocumento", $cadena_xml);
                $err = $connection->getError();
                
                if($err){ throw new Exception('Error al generar documento. <br />'.$err, 1); }
                
                $data = array(
                    'fecha'         => $fecha_emision,
                    'request'       => addslashes(print_r($connection->request,true)),
                    'response'		=> addslashes(print_r($response,true)),
                    'estado_envio'	=> $response["resultado"]["status"],
                    'order_id'      => $params['id_order'],
                    'cart_id'       => $cart->id
                );
                
                if(isset($response['enlaces']['dte_pdf']))
                {
                    $data['enlace_pdf'] = $response['enlaces']['dte_pdf'];
                }
                if(!Db::getInstance()->insert('facto_log', $data))
                { 
                    throw new Exception('Error al insertar datos <br />', 2); 
                }
                
            }catch(Exeption $e){
                $this->context->smarty->assing($e->getMessage());
            }
        }
    }
    
    public function hookActionValidateCustomerAddressForm($params){
        if((bool)Tools::isSubmit('confirm-addresses')){
            $factoValues    = (Tools::getValue('facto_tipo_documento')) ? Tools::getValue('facto_tipo_documento'): null;
            $razon_social   = (Tools::getValue('company')) ? Tools::getValue('company'): null;
            $rut_empresa    = (Tools::getValue('vat_number')) ? Tools::getValue('vat_number'): null;
            $giro           = (Tools::getValue('other')) ? Tools::getValue('other'): null;
            
            $this->setFactoValues($params['cart']->id, $factoValues, $rut_empresa, $razon_social, $giro);
        }
    }
    
    public function hookDisplayOrderConfirmation($params){
        $sql_order = '  SELECT order_id, cart_id, enlace_pdf
                        FROM '._DB_PREFIX_.'facto_log
                        WHERE order_id = "'.$params['order']->id.'" AND 
                              estado_envio IN (0,2)';
        $query_order = Db::getInstance()->getRow($sql_order);
        
        if($query_order != false)
        {
            if($query_order['enlace_pdf'] != ''){
                $pdf = $query_order['enlace_pdf'];
                $this->context->smarty->assign('facto_enlace', $pdf);
            }else{
                $this->context->smarty->assign('facto_error', $this->l('An error occurred while generating your electronic invoice / ticket. Please contact an administrator.'));
            }
        }else{
            $cart_id = Cart::getCartIdByOrderId($params['order']->id);
            $factoValues = $this->getFactoValues($cart_id);
            
            if($factoValues['tipo'] == ""){
                $sql_last = '   SELECT tipo, rut, razon_social, giro
                                FROM '._DB_PREFIX_.'facto fa
                                    INNER JOIN '._DB_PREFIX_.'cart ca ON(ca.id_cart = fa.cart_id)
                                    INNER JOIN '._DB_PREFIX_.'customer cu ON(cu.id_customer = ca.id_customer)
                                    INNER JOIN '._DB_PREFIX_.'cart ca2 ON(cu.id_customer = ca2.id_customer)
                                WHERE ca2.id_cart = '.$cart_id.'
                                ORDER BY ca.id_cart DESC; ';
                $query_last = DB::getInstance()->getRow($sql_last);
                if($query_last != false){
                    $this->setFactoValues($cart_id, $query_last['tipo'], $query_last['rut'], $query_last['razon_social'], $query_last['giro']);
                }
            }
            $this->context->smarty->assign('facto_error', $this->l('Boleta/Factura electrónica will be generated by an administrator once your order is confirmed.'));
        }
        return $this->display(__FILE__, 'views/templates/front/order-confirmation.tpl');
    }
    
    /**
     * Funciones especificas 
     **/
    protected  static function setFactoValues($cart_id, $tipo, $rut, $razon_social, $giro){
        $sql_values = ' INSERT INTO '._DB_PREFIX_.'facto(cart_id, tipo, rut, razon_social, giro)
                        VALUES ('.$cart_id.', '.$tipo.', "'.$rut.'", "'.$razon_social.'", "'.$giro.'")
                        ON DUPLICATE KEY UPDATE tipo = '.$tipo.', rut = "'.$rut.'", razon_social = "'.$razon_social.'", giro = "'.$giro.'"; ';
        return Db::getInstance()->execute($sql_values);
    }
    
    protected  static function getFactoValues($cart_id){
        $sql_values = ' SELECT tipo, rut, razon_social, giro
                        FROM '._DB_PREFIX_.'facto
                        WHERE cart_id = '.$cart_id;
        
        return Db::getInstance()->getRow($sql_values);
    }
    
    protected function setEncodingXml($origen){
        if (mb_detect_encoding($origen, "UTF-8,ISO-8859-1",true) != 'UTF-8'){
            $origen = iconv("ISO-8859-1","UTF-8//TRANSLIT",$origen);
        }
        
        $origen = str_replace("&","&amp;",$origen);
        $origen = str_replace("<","&lt;",$origen);
        $origen = str_replace(">","&gt;",$origen);
        
        return $origen;
    }
    
    protected static function isRUT($rut){
        if(strpos($rut,"-")==false){
            $RUT[0] = substr($rut, 0, -1);
            $RUT[1] = substr($rut, -1);
        }else{
            $RUT = explode("-", trim($rut));
        }
        
        $elRut = str_replace(".", "", trim($RUT[0]));
        $factor = 2;
        $suma = 0;
        
        for($i = strlen($elRut)-1; $i >= 0; $i--){
            $factor = $factor > 7 ? 2 : $factor;
            $suma += $elRut{$i}*$factor++;
        }
        $resto = $suma % 11;
        $dv = 11 - $resto;
        
        if($dv == 11) $dv="0";
        else if($dv == 10) $dv="k";
        else $dv=(string)$dv;
        
        if($dv == trim(strtolower($RUT[1]))) return true;
        else return false;        
    }
}
