<?php
/**
* 2007-2019 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2019 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/
$sql = array();

$listacomunas = array(
    '11201' => 'Aisén',
    '05602' => 'Algarrobo',
    '13502' => 'Alhué',
    '08314' => 'Alto Biobío',
    '03302' => 'Alto Del Carmen',
    '01107' => 'Alto Hospicio',
    '10202' => 'Ancud',
    '04103' => 'Andacollo',
    '09201' => 'Angol',
    '12202' => 'Antártica',
    '02101' => 'Antofagasta',
    '08302' => 'Antuco',
    '08202' => 'Arauco',
    '15101' => 'Arica',
    '13402' => 'Buin',
    '08402' => 'Bulnes',
    '05402' => 'Cabildo',
    '12201' => 'Cabo de Hornos',
    '08303' => 'Cabrero',
    '02201' => 'Calama',
    '10102' => 'Calbuco',
    '03102' => 'Caldera',
    '05502' => 'Calera',
    '13403' => 'Calera De Tango',
    '05302' => 'Calle Larga',
    '15102' => 'Camarones',
    '01402' => 'Camiña',
    '04202' => 'Canela',
    '08203' => 'Cañete',
    '09102' => 'Carahue',
    '05603' => 'Cartagena',
    '05102' => 'Casablanca',
    '10201' => 'Castro',
    '05702' => 'Catemu',
    '07201' => 'Cauquenes',
    '13102' => 'Cerrillos',
    '13103' => 'Cerro Navia',
    '10401' => 'Chaitén',
    '07202' => 'Chanco',
    '03201' => 'Chañaral',
    '06302' => 'Chépica',
    '08103' => 'Chiguayante',
    '11401' => 'Chile Chico',
    '08401' => 'Chillán',
    '08406' => 'Chillán Viejo',
    '06303' => 'Chimbarongo',
    '09121' => 'Cholchol',
    '10203' => 'Chonchi',
    '11202' => 'Cisnes',
    '08403' => 'Cobquecura',
    '10103' => 'Cochamó',
    '11301' => 'Cochrane',
    '06102' => 'Codegua',
    '08404' => 'Coelemu',
    '11101' => 'Coihayque',
    '08405' => 'Coihueco',
    '06103' => 'Coinco',
    '07402' => 'Colbún',
    '01403' => 'Colchane',
    '13301' => 'Colina',
    '09202' => 'Collipulli',
    '06104' => 'Coltauco',
    '04302' => 'Combarbalá',
    '08101' => 'Concepción',
    '13104' => 'Conchalí',
    '05103' => 'Concón',
    '07102' => 'Constitución',
    '08204' => 'Contulmo',
    '03101' => 'Copiapó',
    '04102' => 'Coquimbo',
    '08102' => 'Coronel',
    '14102' => 'Corral',
    '09103' => 'Cunco',
    '09203' => 'Curacautín',
    '13503' => 'Curacaví',
    '10204' => 'Curaco de Velez',
    '08205' => 'Curanilahue',
    '09104' => 'Curarrehue',
    '07103' => 'Curepto',
    '07301' => 'Curicó',
    '10205' => 'Dalcahue',
    '03202' => 'Diego De Almagro',
    '06105' => 'Doñihue',
    '13105' => 'El Bosque',
    '08407' => 'El Carmen',
    '13602' => 'El Monte',
    '06111' => 'El Olivar',
    '05604' => 'El Quisco',
    '05605' => 'El Tabo',
    '07104' => 'Empedrado',
    '09204' => 'Ercilla',
    '13106' => 'Estación Central',
    '08104' => 'Florida',
    '09105' => 'Freire',
    '03303' => 'Freirina',
    '10104' => 'Fresia',
    '10105' => 'Frutillar',
    '10402' => 'Futaleufú',
    '14202' => 'Futrono',
    '09106' => 'Galvarino',
    '15202' => 'General Lagos',
    '09107' => 'Gorbea',
    '06106' => 'Graneros',
    '11203' => 'Guaitecas',
    '05503' => 'Hijuelas',
    '10403' => 'Hualaihue',
    '07302' => 'Hualañe',
    '08112' => 'Hualpén',
    '08105' => 'Hualqui',
    '01404' => 'Huara',
    '03304' => 'Huasco',
    '13107' => 'Huechuraba',
    '04201' => 'Illapel',
    '13108' => 'Independencia',
    '01101' => 'Iquique',
    '13603' => 'Isla De Maipo',
    '05201' => 'Isla De Pascua',
    '05104' => 'Juan Fernández',
    '13109' => 'La Cisterna',
    '05504' => 'La Cruz',
    '06202' => 'La Estrella',
    '13110' => 'La Florida',
    '13111' => 'La Granja',
    '04104' => 'La Higuera',
    '05401' => 'La Ligua',
    '13112' => 'La Pintana',
    '13113' => 'La Reina',
    '04101' => 'La Serena',
    '14201' => 'La Unión',
    '14203' => 'Lago Ranco',
    '11102' => 'Lago Verde',
    '12102' => 'Laguna Blanca',
    '08304' => 'Laja',
    '13302' => 'Lampa',
    '14103' => 'Lanco',
    '06107' => 'Las Cabras',
    '13114' => 'Las Condes',
    '09108' => 'Lautaro',
    '08201' => 'Lebu',
    '07303' => 'Licantén',
    '05802' => 'Limache',
    '07401' => 'Linares',
    '06203' => 'Litueche',
    '05703' => 'Llaillay',
    '10107' => 'Llanquihue',
    '13115' => 'Lo Barnechea',
    '13116' => 'Lo Espejo',
    '13117' => 'Lo Prado',
    '06304' => 'Lolol',
    '09109' => 'Loncoche',
    '07403' => 'Longaví',
    '09205' => 'Lonquimay',
    '08206' => 'Los Alamos',
    '05301' => 'Los Andes',
    '08301' => 'Los Angeles',
    '14104' => 'Los Lagos',
    '10106' => 'Los Muermos',
    '09206' => 'Los Sauces',
    '04203' => 'Los Vilos',
    '08106' => 'Lota',
    '09207' => 'Lumaco',
    '06108' => 'Machali',
    '13118' => 'Macul',
    '14105' => 'Máfil',
    '13119' => 'Maipú',
    '06109' => 'Malloa',
    '06204' => 'Marchihue',
    '02302' => 'María Elena',
    '13504' => 'María Pinto',
    '14106' => 'Mariquina',
    '07105' => 'Maule',
    '10108' => 'Maullín',
    '02102' => 'Mejillones',
    '09110' => 'Melipeuco',
    '13501' => 'Melipilla',
    '07304' => 'Molina',
    '04303' => 'Monte Patria',
    '06110' => 'Mostazal',
    '08305' => 'Mulchén',
    '08306' => 'Nacimiento',
    '06305' => 'Nancagua',
    '12401' => 'Natales',
    '06205' => 'Navidad',
    '08307' => 'Negrete',
    '08408' => 'Ninhue',
    '05506' => 'Nogales',
    '09111' => 'Nueva Imperial',
    '08409' => 'Ñiquén',
    '13120' => 'Ñuñoa',
    '11302' => 'O\'Higgins',
    '02202' => 'Ollague',
    '05803' => 'Olmué',
    '10301' => 'Osorno',
    '04301' => 'Ovalle',
    '13604' => 'Padre Hurtado',
    '09112' => 'Padre Las Casas',
    '04105' => 'Paiguano',
    '14107' => 'Paillaco',
    '13404' => 'Paine',
    '10404' => 'Palena',
    '06306' => 'Palmilla',
    '14108' => 'Panguipulli',
    '05704' => 'Panquehue',
    '05403' => 'Papudo',
    '06206' => 'Paredones',
    '07404' => 'Parral',
    '13121' => 'Pedro Aguirre Cerda',
    '07106' => 'Pelarco',
    '07203' => 'Pelluhue',
    '08410' => 'Pemuco',
    '07107' => 'Pencahue',
    '08107' => 'Penco',
    '13605' => 'Peñaflor',
    '13122' => 'Peñalolén',
    '06307' => 'Peralillo',
    '09113' => 'Perquenco',
    '05404' => 'Petorca',
    '06112' => 'Peumo',
    '01405' => 'Pica',
    '06113' => 'Pichidegua',
    '06201' => 'Pichilemu',
    '08411' => 'Pinto',
    '13202' => 'Pirque',
    '09114' => 'Pitrufquén',
    '06308' => 'Placilla',
    '08412' => 'Portezuelo',
    '12301' => 'Porvenir',
    '01401' => 'Pozo Almonte',
    '12302' => 'Primavera',
    '13123' => 'Providencia',
    '05105' => 'Puchuncaví',
    '09115' => 'Pucón',
    '13124' => 'Pudahuel',
    '13201' => 'Puente Alto',
    '10101' => 'Puerto Montt',
    '10302' => 'Puerto Octay',
    '10109' => 'Puerto Varas',
    '06309' => 'Pumanque',
    '04304' => 'Punitaqui',
    '12101' => 'Punta Arenas',
    '10206' => 'Puqueldón',
    '09208' => 'Puren',
    '10303' => 'Purranque',
    '05705' => 'Putaendo',
    '15201' => 'Putre',
    '10304' => 'Puyehue',
    '10207' => 'Queilén',
    '10208' => 'Quellón',
    '10209' => 'Quemchi',
    '08308' => 'Quilaco',
    '13125' => 'Quilicura',
    '08309' => 'Quilleco',
    '08413' => 'Quillón',
    '05501' => 'Quillota',
    '05801' => 'Quilpué',
    '10210' => 'Quinchao',
    '06114' => 'Quinta De Tilcoco',
    '13126' => 'Quinta Normal',
    '05107' => 'Quintero',
    '08414' => 'Quirihue',
    '06101' => 'Rancagua',
    '08415' => 'Ranquil',
    '07305' => 'Rauco',
    '13127' => 'Recoleta',
    '09209' => 'Renaico',
    '13128' => 'Renca',
    '06115' => 'Rengo',
    '06116' => 'Requinoa',
    '07405' => 'Retiro',
    '05303' => 'Rinconada',
    '14204' => 'Río Bueno',
    '07108' => 'Río Claro',
    '04305' => 'Río Hurtado',
    '11402' => 'Río Ibáñez',
    '10305' => 'Río Negro',
    '12103' => 'Río Verde',
    '07306' => 'Romeral',
    '09116' => 'Saavedra',
    '07307' => 'Sagrada Familia',
    '04204' => 'Salamanca',
    '05601' => 'San Antonio',
    '13401' => 'San Bernardo',
    '08416' => 'San Carlos',
    '07109' => 'San Clemente',
    '05304' => 'San Esteban',
    '08417' => 'San Fabián',
    '05701' => 'San Felipe',
    '06301' => 'San Fernando',
    '12104' => 'San Gregorio',
    '08418' => 'San Ignacio',
    '07406' => 'San Javier',
    '13129' => 'San Joaquín',
    '13203' => 'San José De Maipo',
    '10306' => 'San Juan de la Costa',
    '13130' => 'San Miguel',
    '08419' => 'San Nicolás',
    '10307' => 'San Pablo',
    '13505' => 'San Pedro',
    '02203' => 'San Pedro De Atacama',
    '08108' => 'San Pedro de la Paz',
    '07110' => 'San Rafael',
    '13131' => 'San Ramón',
    '08310' => 'San Rosendo',
    '06117' => 'San Vicente',
    '08311' => 'Santa Bárbara',
    '06310' => 'Santa Cruz',
    '08109' => 'Santa Juana',
    '05706' => 'Santa María',
    '13101' => 'Santiago',
    '05606' => 'Santo Domingo',
    '02103' => 'Sierra Gorda',
    '13601' => 'Talagante',
    '07101' => 'Talca',
    '08110' => 'Talcahuano',
    '02104' => 'Taltal',
    '09101' => 'Temuco',
    '07308' => 'Teno',
    '09117' => 'Teodoro Schmidt',
    '03103' => 'Tierra Amarilla',
    '13303' => 'Tiltil',
    '12303' => 'Timaukel',
    '08207' => 'Tirua',
    '02301' => 'Tocopilla',
    '09118' => 'Toltén',
    '08111' => 'Tomé',
    '12402' => 'Torres del Paine',
    '11303' => 'Tortel',
    '09210' => 'Traiguén',
    '08420' => 'Treguaco',
    '08312' => 'Tucapel',
    '14101' => 'Valdivia',
    '03301' => 'Vallenar',
    '05101' => 'Valparaíso',
    '07309' => 'Vichuquén',
    '09211' => 'Victoria',
    '04106' => 'Vicuña',
    '09119' => 'Vilcún',
    '07407' => 'Villa Alegre',
    '05804' => 'Villa Alemana',
    '09120' => 'Villarrica',
    '05109' => 'Viña Del Mar',
    '13132' => 'Vitacura',
    '07408' => 'Yerbas Buenas',
    '08313' => 'Yumbel',
    '08421' => 'Yungay',
    '05405' => 'Zapallar');


$sql[0] = ' CREATE TABLE IF NOT EXISTS ' . _DB_PREFIX_ . 'facto (
                cart_id int(11) NOT NULL AUTO_INCREMENT,
                tipo varchar(3),
                rut varchar(255),
                razon_social varchar(255),
                giro varchar(255),
                PRIMARY KEY  (cart_id)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

$sql[1] = ' CREATE TABLE IF NOT EXISTS '. _DB_PREFIX_ .'facto_log (
                id int(11) NOT NULL AUTO_INCREMENT,
				fecha date,
			    request text,
				response text,
				estado_envio int(11),
			    order_id int,
				cart_id int,
			    enlace_pdf text,
				PRIMARY KEY (id)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';
    
$sql[2] = ' UPDATE '._DB_PREFIX_.'country
            SET contains_states = 1
            WHERE iso_code = "CL"';
// Hacemos una consulta a la tabla de formato de direccion segun el iso_code de Chile
    $sql_address_format = ' SELECT format
                            FROM '._DB_PREFIX_.'address_format
                            WHERE id_country = (SELECT id_country FROM '._DB_PREFIX_.'country WHERE iso_code = "CL")';
    $query_address_format = Db::getInstance()->getRow($sql_address_format);
    $format = $query_address_format['format'];
    if(strpos($format, 'facto_tipo_documento') == false) $format = 'facto_tipo_documento
'.$format;
    if(strpos($format, 'State:name') == false) $format .= '
State:name ';
    if(strpos($format, 'other') == false) $format .= '
other ';
    if(strpos($format, 'address2') == true) $format = str_replace('address2', '', $format);

$sql[3] = ' UPDATE '._DB_PREFIX_.'address_format
                SET FORMAT = "'.$format.'"
                WHERE id_country = (SELECT id_country
                                    FROM '._DB_PREFIX_.'country
                                    WHERE iso_code = "CL")';

$sql_state = '  SELECT COUNT(id_state) AS cant
                FROM '._DB_PREFIX_.'state
                WHERE id_country = (SELECT id_country 
                                    FROM '._DB_PREFIX_.'country 
                                    WHERE iso_code = "CL")';

$query_state = Db::getInstance()->getRow($sql_state);

    if($query_state['cant'] == 0){
        $sql_country = 'SELECT id_country, id_zone
                        FROM '._DB_PREFIX_.'country
                        WHERE iso_code = "CL"';
        $query_country = Db::getInstance()->getRow($sql_country);
        
        foreach ($listacomunas as $codigo => $comuna){
            $sql_states = ' INSERT '._DB_PREFIX_.'state (id_country, id_zone, name, iso_code, tax_behavior, active)
                            VALUES('.$query_country['id_country'].', '.$query_country['id_zone'].', 
                                    "'.addslashes($comuna).'", "'.$codigo.'", 0, 1)';
            Db::getInstance()->execute($sql_states);
        }
    }
    
$sql_translate_state = ' SELECT COUNT(id_translation) AS cantidad
                        FROM '._DB_PREFIX_.'translation tr
                        WHERE id_lang = 1 AND tr.key = "State" AND theme = "classic"';
    $query_translate_state = db::getinstance()->getRow($sql_translate_state);
    if($query_translate_state['cantidad'] == 0) Db::getInstance()->execute('INSERT INTO '._DB_PREFIX_.'translation(`id_lang`, `key`, `translation`, `domain`, `theme`) VALUES(1, "State", "Comuna", "ShopFormsLabels", "classic")');
    
$sql_translate_vat_number = '    SELECT COUNT(id_translation) AS cantidad
                                FROM '._DB_PREFIX_.'translation tr
                                WHERE id_lang = 1 AND tr.key = "VAT number" AND theme = "classic"';
    $query_translate_state = db::getinstance()->getRow($sql_translate_vat_number);
    if($query_translate_state['cantidad'] == 0) Db::getInstance()->execute('INSERT INTO '._DB_PREFIX_.'translation(`id_lang`, `key`, `translation`, `domain`, `theme`) VALUES(1, "VAT number", "RUT Empresa", "ShopFormsLabels", "classic")');

$sql_translate_company = '   SELECT COUNT(id_translation) AS cantidad
                            FROM '._DB_PREFIX_.'translation tr
                            WHERE id_lang = 1 AND tr.key = "Company" AND theme = "classic"';
    $query_translate_company = db::getinstance()->getRow($sql_translate_company);
    if($query_translate_company['cantidad'] == 0) Db::getInstance()->execute('INSERT INTO '._DB_PREFIX_.'translation(`id_lang`, `key`, `translation`, `domain`, `theme`) VALUES(1, "Company", "Razon Social Empresa", "ShopFormsLabels", "classic")');

$sql_translate_warehouse = '   SELECT COUNT(id_translation) AS cantidad
                            FROM '._DB_PREFIX_.'translation tr
                            WHERE id_lang = 1 AND tr.key = "Warehouse" AND theme = "classic"';
    $query_translate_warehouse = db::getinstance()->getRow($sql_translate_warehouse);
    if($query_translate_warehouse['cantidad'] == 0) Db::getInstance()->execute('INSERT INTO '._DB_PREFIX_.'translation(`id_lang`, `key`, `translation`, `domain`, `theme`) VALUES(1, "Warehouse", "Tipo Documento", "ShopFormsLabels", "classic")');
    
    $sql_translate_other = '   SELECT COUNT(id_translation) AS cantidad
                            FROM '._DB_PREFIX_.'translation tr
                            WHERE id_lang = 1 AND tr.key = "Other" AND theme = "classic"';
    $query_translate_other = db::getinstance()->getRow($sql_translate_other);
    if($query_translate_other['cantidad'] == 0) Db::getInstance()->execute('INSERT INTO '._DB_PREFIX_.'translation(`id_lang`, `key`, `translation`, `domain`, `theme`) VALUES(1, "Other", "Giro", "ShopFormsLabels", "classic")');

foreach ($sql as $query) {
    if (Db::getInstance()->execute($query) == false) {
        return false;
    }
}
