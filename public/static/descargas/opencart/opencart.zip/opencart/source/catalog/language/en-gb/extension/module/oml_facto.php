<?php
 
	$_['heading_title'] = 'FACTO';

?>