<?php
 
	$_['heading_title'] = 'Integración Facto - Opencart';

	$_['text_module']      = 'Modules';
	
	$_['text_edit']        = 'Configuraciones de FACTO';
	$_['text_success']     = 'Las configuraciones han sido guardadas correctamente.';
	
	$_['entry_name']       = 'oml facto';
	
	$_['error_permission']       = 'El usuario no tiene permiso para efectuar esta acci&oacute;n.';
	
?>